﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;
using Moq;
using NUnit.Framework;
using Services.Genericki;

[TestFixture]
public class ProizvodnjaVinaServisTests
{
    private readonly Mock<IVinoRepozitorijum> _vinoRepoMock;
    private readonly Mock<IVinogradarstvoServis> _vinogradarstvoMock;
    private readonly Mock<ILoggerServis> _loggerMock;

    private readonly ProizvodnjaVinaServis _servis;

    public ProizvodnjaVinaServisTests()
    {
        _vinoRepoMock = new Mock<IVinoRepozitorijum>();
        _vinogradarstvoMock = new Mock<IVinogradarstvoServis>();
        _loggerMock = new Mock<ILoggerServis>();

        _vinoRepoMock
            .Setup(r => r.PreuzmiSve())
            .Returns(new List<Vino>());

        _servis = new ProizvodnjaVinaServis(
            _vinoRepoMock.Object,
            _vinogradarstvoMock.Object,
            _loggerMock.Object
        );
    }

    [Test]
    public void EvidentirajVino_NevalidanNaziv_RepoSeNePoziva_I_LogujeGresku()
    {
        // Act
        _servis.EvidentirajVino("", KategorijaVina.Stolno, 1.0, "L1");

        // Assert
        _vinoRepoMock.Verify(r => r.Dodaj(It.IsAny<Vino>()), Times.Never);

        _loggerMock.Verify(l =>
            l.EvidentirajDogadjaj(
                TipEvidencije.ERROR,
                It.Is<string>(s => s.Contains("Nevalidni parametri"))
            ),
            Times.Once
        );
    }

    [Test]
    public void EvidentirajVino_ValidniPodaci_DodajeVino_URepo()
    {
        // Act
        _servis.EvidentirajVino(
            "Merlot",
            KategorijaVina.Stolno,
            0.75,
            "LOZA-123"
        );

        // Assert
        _vinoRepoMock.Verify(r =>
            r.Dodaj(It.Is<Vino>(v =>
                !string.IsNullOrWhiteSpace(v.SifraSerije) &&   // string kao šifra
                v.Naziv == "Merlot" &&
                v.Zapremina == 0.75 &&
                v.IdLoze == "LOZA-123"
            )),
            Times.Once
        );
    }

    [Test]
    public void PokreniFermentaciju_BrojFlasaManjiOdJedan_VracaPrazno_I_LogujeGresku()
    {
        // Act
        var result = _servis.PokreniFermentaciju(
            "Cabernet",
            KategorijaVina.Stolno,
            0,
            ZapreminaFlase.Mala,
            "Merlot",
            "Sumadija"
        );

        // Assert
        Assert.That(result, Is.Empty);

        _loggerMock.Verify(l =>
            l.EvidentirajDogadjaj(
                TipEvidencije.ERROR,
                It.Is<string>(s => s.Contains("Broj flaša"))
            ),
            Times.Once
        );
    }

    [Test]
    public void PokreniFermentaciju_DovoljnoLoza_ProizvodiTacnoOnolikoVinaKolikoTreba()
    {
        // Arrange
        var loze = new List<Loza>
    {
        new Loza { Id = "L1", NivoSecera = 22.0 },
        new Loza { Id = "L2", NivoSecera = 23.0 }
    };

        _vinogradarstvoMock
            .Setup(v => v.ObratiLoze("Merlot", It.IsAny<int>()))
            .Returns((loze, 0));

        var dodataVina = new List<Vino>();

        _vinoRepoMock
            .Setup(r => r.Dodaj(It.IsAny<Vino>()))
            .Callback<Vino>(v => dodataVina.Add(v));

        _vinoRepoMock
            .Setup(r => r.PreuzmiSve())
            .Returns(() => dodataVina);

        // Act
        var rezultat = _servis.PokreniFermentaciju(
            "Merlot",
            KategorijaVina.Stolno,
            3,
            ZapreminaFlase.Mala,
            "Merlot",
            "Sumadija"
        );

        // Assert
        Assert.That(rezultat.Count(), Is.EqualTo(2));
    }

    [Test]
    public void PokreniFermentaciju_ObratiLozeVratiNull_VracaPrazno()
    {
        _vinogradarstvoMock
            .Setup(v => v.ObratiLoze(It.IsAny<string>(), It.IsAny<int>()))
            .Returns((null, 0));

        var result = _servis.PokreniFermentaciju(
            "Merlot",
            KategorijaVina.Premijum,
            5,
            ZapreminaFlase.Velika,
            "Chardonnay",
            "Backa"
        );

        Assert.That(result, Is.Empty);
    }

}
