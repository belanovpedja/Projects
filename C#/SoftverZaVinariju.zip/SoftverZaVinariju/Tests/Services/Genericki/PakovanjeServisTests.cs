﻿using System;
using System.Collections.Generic;
using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;
using Moq;
using NUnit.Framework;
using Services.Genericki;

[TestFixture]
public class PakovanjeServisTests
{
    private Mock<IPaletaRepozitorijum> _paletaRepo;
    private Mock<IVinoRepozitorijum> _vinoRepo;
    private Mock<ILozaRepozitorijum> _lozaRepo;
    private Mock<IPodrumRepozitorijum> _podrumRepo;
    private Mock<IProizvodnjaVinaServis> _proizvodnjaServis;
    private Mock<ILoggerServis> _logger;

    private PakovanjeServis _servis;

    [SetUp]
    public void Setup()
    {
        _paletaRepo = new Mock<IPaletaRepozitorijum>();
        _vinoRepo = new Mock<IVinoRepozitorijum>();
        _lozaRepo = new Mock<ILozaRepozitorijum>();
        _podrumRepo = new Mock<IPodrumRepozitorijum>();
        _proizvodnjaServis = new Mock<IProizvodnjaVinaServis>();
        _logger = new Mock<ILoggerServis>();

        _servis = new PakovanjeServis(
            _paletaRepo.Object,
            _vinoRepo.Object,
            _lozaRepo.Object,
            _podrumRepo.Object,
            _proizvodnjaServis.Object,
            _logger.Object
        );
    }

    // =======================
    // PregledPaleta
    // =======================

    [Test]
    public void PregledPaleta_VracaSvePaleteIzRepozitorijuma()
    {
        _paletaRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<Paleta> { new Paleta(), new Paleta() });

        var rezultat = _servis.PregledPaleta();

        Assert.That(rezultat, Has.Exactly(2).Items);
    }

    // =======================  //mislim da ovde ima greska momci, ne u testu nego u funkciji, ispravicu kad se testovi odobre (poruka koja se ovde vraca se koristi kao sifra a ne kao opis operacije)
    // KreirajPaletu
    // =======================

    [Test]
    public void KreirajPaletu_ValidniPodaci_DodajePaletu()
    {
        _podrumRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<VinskiPodrum>
            {
                new VinskiPodrum { Id = "P1" }
            });

        _proizvodnjaServis.Setup(p => p.PregledSvihVina())
            .Returns(new List<Vino>
            {
                new Vino { SifraSerije = "V1" }
            });

        _paletaRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<Paleta>());

        var (uspeh, _) = _servis.KreirajPaletu(
            "Beograd",
            "P1",
            new List<string> { "V1" }
        );

        Assert.That(uspeh, Is.True);
        _paletaRepo.Verify(r => r.Dodaj(It.IsAny<Paleta>()), Times.Once);
    }

    [Test]
    public void KreirajPaletu_PraznaAdresa_VracaGresku()
    {
        var (uspeh, _) = _servis.KreirajPaletu(
            "",
            "P1",
            new List<string> { "V1" }
        );

        Assert.That(uspeh, Is.False);
        _paletaRepo.Verify(r => r.Dodaj(It.IsAny<Paleta>()), Times.Never);
    }

    [Test]
    public void KreirajPaletu_NepostojeciPodrum_VracaGresku()
    {
        _podrumRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<VinskiPodrum>());

        var (uspeh, _) = _servis.KreirajPaletu(
            "Novi Sad",
            "NEPOSTOJI",
            new List<string> { "V1" }
        );

        Assert.That(uspeh, Is.False);
    }

    [Test]
    public void KreirajPaletu_VinoVecSpakovano_VracaGresku()
    {
        _podrumRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<VinskiPodrum>
            {
                new VinskiPodrum { Id = "P1" }
            });

        _proizvodnjaServis.Setup(p => p.PregledSvihVina())
            .Returns(new List<Vino>
            {
                new Vino { SifraSerije = "V1" }
            });

        _paletaRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<Paleta>
            {
                new Paleta { SpisakVinaIds = new List<string> { "V1" } }
            });

        var (uspeh, _) = _servis.KreirajPaletu(
            "Beograd",
            "P1",
            new List<string> { "V1" }
        );

        Assert.That(uspeh, Is.False);
    }

    // =======================
    // OtpremiPaletu
    // =======================

    [Test]
    public void OtpremiPaletu_PaletaNePostoji_VracaGresku()
    {
        _paletaRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<Paleta>());

        var (uspeh, _) = _servis.OtpremiPaletu("PAL-1", "P1");

        Assert.That(uspeh, Is.False);
    }

    [Test]
    public void OtpremiPaletu_PodrumPun_VracaGresku()
    {
        var paleta = new Paleta
        {
            Sifra = "PAL-1",
            Status = StatusPalete.Upakovana,
            IdVinskogPodruma = "P1"
        };

        _paletaRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<Paleta>
            {
                paleta,
                new Paleta { Status = StatusPalete.Otpremljena, IdVinskogPodruma = "P1" }
            });

        _podrumRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<VinskiPodrum>
            {
                new VinskiPodrum
                {
                    Id = "P1",
                    Naziv = "Centralni",
                    MaksimalniKapacitetPaleta = 1
                }
            });

        var (uspeh, _) = _servis.OtpremiPaletu("PAL-1", "P1");

        Assert.That(uspeh, Is.False);
        _paletaRepo.Verify(r => r.Azuriraj(It.IsAny<Paleta>()), Times.Never);
    }

    [Test]
    public void OtpremiPaletu_ValidniPodaci_MenjaStatusNaOtpremljena()
    {
        var paleta = new Paleta
        {
            Sifra = "PAL-1",
            Status = StatusPalete.Upakovana,
            IdVinskogPodruma = "P1"
        };

        _paletaRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<Paleta> { paleta });

        _podrumRepo.Setup(r => r.PreuzmiSve())
            .Returns(new List<VinskiPodrum>
            {
                new VinskiPodrum
                {
                    Id = "P1",
                    Naziv = "Centralni",
                    MaksimalniKapacitetPaleta = 10
                }
            });

        var (uspeh, _) = _servis.OtpremiPaletu("PAL-1", "P1");

        Assert.That(uspeh, Is.True);
        Assert.That(paleta.Status, Is.EqualTo(StatusPalete.Otpremljena));
        _paletaRepo.Verify(r => r.Azuriraj(paleta), Times.Once);
    }

    // =======================
    // Raspakuj
    // =======================

    [Test]
    public void Raspakuj_VracaPostojecaVina()
    {
        var paleta = new Paleta
        {
            SpisakVinaIds = new List<string> { "V1", "V2" }
        };

        _vinoRepo.Setup(r => r.PreuzmiSaId("V1"))
            .Returns(new Vino { SifraSerije = "V1" });

        _vinoRepo.Setup(r => r.PreuzmiSaId("V2"))
            .Returns((Vino)null);

        var rezultat = _servis.Raspakuj(paleta);

        Assert.That(rezultat, Has.Exactly(1).Items);
    }

    // =======================
    // DelegirajFermentacijuBuraz
    // =======================

    [Test]
    public void DelegirajFermentaciju_PozivaServisZaProizvodnju()
    {
        var vino = new Vino
        {
            SifraSerije = "V1",
            Naziv = "Merlot",
            Kategorija = KategorijaVina.Kvalitetno,
            IdLoze = "L1"
        };

        var loza = new Loza
        {
            Id = "L1",
            Naziv = "Merlot Loza",
            Region = "Sumadija"
        };

        _vinoRepo.Setup(r => r.PreuzmiSaId("V1")).Returns(vino);
        _lozaRepo.Setup(r => r.PreuzmiSaId("L1")).Returns(loza);

        _servis.DelegirajFermentacijuBuraz("V1", 100);

        _proizvodnjaServis.Verify(p =>
            p.PokreniFermentaciju(
                "Merlot",
                KategorijaVina.Kvalitetno,
                100,
                ZapreminaFlase.Velika,
                "Merlot Loza",
                "Sumadija"
            ),
            Times.Once
        );
    }
}
