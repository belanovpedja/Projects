﻿using Domain.Enumeracije;
using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class FakturaTests
{
    [Test]
    public void Konstruktor_KreiraValidnuFakturu()
    {
        Faktura faktura = new Faktura
        {
            Tip = TipProdaje.Restoranska,
            Placanje = NacinPlacanja.Gotovina,
            UkupanIznos = 5000
        };

        Assert.That(faktura, Is.Not.Null);
        Assert.That(faktura.Tip, Is.EqualTo(TipProdaje.Restoranska));
        Assert.That(faktura.Placanje, Is.EqualTo(NacinPlacanja.Gotovina));
        Assert.That(faktura.UkupanIznos, Is.EqualTo(5000));
    }

    [Test]
    public void Id_AutomatskiSeGenerise()
    {
        Faktura faktura1 = new Faktura();
        Faktura faktura2 = new Faktura();

        Assert.That(faktura1.Id, Is.Not.EqualTo(faktura2.Id));
    }

    [Test]
    public void Stavke_InicijalizujeSeSaPraznomListom()
    {
        Faktura faktura = new Faktura();
        Assert.That(faktura.Stavke, Is.Not.Null);
        Assert.That(faktura.Stavke, Is.Empty);
    }

    [Test]
    public void Datum_AutomatskiSePostavlja()
    {
        Faktura faktura = new Faktura();
        Assert.That(faktura.Datum, Is.EqualTo(DateTime.Now).Within(TimeSpan.FromSeconds(1)));
    }
}