﻿using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class StavkaFaktureTests
{
    [Test]
    public void Konstruktor_KreiraValidnuStavku()
    {
        StavkaFakture stavka = new StavkaFakture
        {
            NazivVina = "Cabernet Reserve",
            Kolicina = 10,
            CenaPoKomadu = 1200
        };

        Assert.That(stavka, Is.Not.Null);
        Assert.That(stavka.NazivVina, Is.EqualTo("Cabernet Reserve"));
        Assert.That(stavka.Kolicina, Is.EqualTo(10));
        Assert.That(stavka.CenaPoKomadu, Is.EqualTo(1200));
    }

    [Test]
    [TestCase(5, 1000, 5000)]
    [TestCase(10, 1200, 12000)]
    [TestCase(1, 850, 850)]
    public void Ukupno_RacunaSePravilno(int kolicina, double cena, double ocekivano)
    {
        StavkaFakture stavka = new StavkaFakture
        {
            Kolicina = kolicina,
            CenaPoKomadu = cena
        };

        Assert.That(stavka.Ukupno, Is.EqualTo(ocekivano));
    }

    [Test]
    public void Ukupno_VracaNuluZaPraznuStavku()
    {
        StavkaFakture stavka = new StavkaFakture();
        Assert.That(stavka.Ukupno, Is.EqualTo(0));
    }
}