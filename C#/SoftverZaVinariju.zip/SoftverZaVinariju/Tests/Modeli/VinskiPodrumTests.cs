﻿using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class VinskiPodrumTests
{
    [Test]
    public void Konstruktor_KreiraValidanPodrum()
    {
        VinskiPodrum podrum = new VinskiPodrum
        {
            Naziv = "Glavni podrum",
            Temperatura = 12.5,
            MaksimalniKapacitetPaleta = 150
        };

        Assert.That(podrum, Is.Not.Null);
        Assert.That(podrum.Naziv, Is.EqualTo("Glavni podrum"));
        Assert.That(podrum.Temperatura, Is.EqualTo(12.5));
        Assert.That(podrum.MaksimalniKapacitetPaleta, Is.EqualTo(150));
    }

    [Test]
    public void Id_AutomatskiSeGenerise()
    {
        VinskiPodrum podrum1 = new VinskiPodrum();
        VinskiPodrum podrum2 = new VinskiPodrum();

        Assert.That(podrum1.Id, Is.Not.EqualTo(podrum2.Id));
    }

    [Test]
    public void ToString_VracaDobarFormat()
    {
        VinskiPodrum podrum = new VinskiPodrum
        {
            Naziv = "Test Podrum",
            Temperatura = 13.0,
            MaksimalniKapacitetPaleta = 100
        };

        string rezultat = podrum.ToString();

        Assert.That(rezultat, Does.Contain("Test Podrum"));
        Assert.That(rezultat, Does.Contain("13"));
        Assert.That(rezultat, Does.Contain("100"));
    }
}