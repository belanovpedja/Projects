﻿using Domain.Enumeracije;
using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class KorisnikTests
{
    [Test]
    [TestCase("Vlada", "123", "Vlada", "Radlovacki")]
    [TestCase("Dimitrije", "1234", "Dimitrije", "Puja")]
    [TestCase("Igor", "12345", "Igor", "Cvijic")]
    [TestCase("Predrag", "12", "Predrag", "Belanov")]
    public void KonstruktorOkej(string korisnickoIme, string lozinka, string ime, string prezime)
    {
        Korisnik korisnik = new(korisnickoIme, lozinka, ime, prezime, TipKorisnika.GlavniEnolog);

        Assert.That(korisnik, Is.Not.Null);
        Assert.That(korisnik.KorisnickoIme, Is.EqualTo(korisnickoIme));
        Assert.That(korisnik.Lozinka, Is.EqualTo(lozinka));
        Assert.That(korisnik.Ime, Is.EqualTo(ime));
        Assert.That(korisnik.Prezime, Is.EqualTo(prezime));
    }

    [Test]
    public void PrazanKonstruktor_KreiraValidanObjekat()
    {
        var korisnik = new Korisnik();

        Assert.That(korisnik, Is.Not.Null);
        Assert.That(korisnik.Id, Is.EqualTo(0));
        Assert.That(korisnik.KorisnickoIme, Is.EqualTo(string.Empty));
    }

    [Test]
    public void Uloga_MozeSePodesiti()
    {
        var korisnik = new Korisnik
        {
            Uloga = TipKorisnika.Kelar
        };

        Assert.That(korisnik.Uloga, Is.EqualTo(TipKorisnika.Kelar));
    }
}