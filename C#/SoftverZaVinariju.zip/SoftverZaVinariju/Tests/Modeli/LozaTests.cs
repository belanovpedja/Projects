﻿using Domain.Enumeracije;
using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class LozaTests
{
    [Test]
    public void Konstruktor_KreiraValidnuLozu()
    {
        Loza loza = new Loza
        {
            Naziv = "Cabernet Sauvignon",
            NivoSecera = 22.5,
            GodinaSadnje = 2020,
            Region = "Vrsac",
            Faza = FazaZrelosti.SpremnaZaBerbu
        };

        Assert.That(loza, Is.Not.Null);
        Assert.That(loza.Naziv, Is.EqualTo("Cabernet Sauvignon"));
        Assert.That(loza.NivoSecera, Is.EqualTo(22.5));
        Assert.That(loza.GodinaSadnje, Is.EqualTo(2020));
        Assert.That(loza.Region, Is.EqualTo("Vrsac"));
        Assert.That(loza.Faza, Is.EqualTo(FazaZrelosti.SpremnaZaBerbu));
    }

    [Test]
    public void Id_AutomatskiSeGenerise()
    {
        Loza loza1 = new Loza();
        Loza loza2 = new Loza();

        Assert.That(loza1.Id, Is.Not.EqualTo(loza2.Id));
    }

    [Test]
    public void ToString_VracaDobarFormat()
    {
        Loza loza = new Loza
        {
            Naziv = "Merlot",
            Region = "Negotinska Krajina",
            GodinaSadnje = 2019,
            Faza = FazaZrelosti.Zrenje,
            NivoSecera = 21.8
        };

        string rezultat = loza.ToString();

        Assert.That(rezultat, Does.Contain("Merlot"));
        Assert.That(rezultat, Does.Contain("Negotinska Krajina"));
        Assert.That(rezultat, Does.Contain("21,8"));
    }

    [Test]
    [TestCase(15.0)]
    [TestCase(20.5)]
    [TestCase(28.0)]
    public void NivoSecera_PrihvataValidneVrednosti(double nivo)
    {
        Loza loza = new Loza { NivoSecera = nivo };
        Assert.That(loza.NivoSecera, Is.EqualTo(nivo));
    }
}