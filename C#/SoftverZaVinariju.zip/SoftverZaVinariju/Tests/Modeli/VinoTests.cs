﻿using Domain.Enumeracije;
using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class VinoTests
{
    [Test]
    public void Konstruktor_KreiraValidnoVino()
    {
        Vino vino = new Vino
        {
            SifraSerije = "VN-2025-TEST123",
            Naziv = "Cabernet Reserve",
            Kategorija = KategorijaVina.Premijum,
            Zapremina = 0.75,
            IdLoze = "loza-123"
        };

        Assert.That(vino, Is.Not.Null);
        Assert.That(vino.SifraSerije, Is.EqualTo("VN-2025-TEST123"));
        Assert.That(vino.Naziv, Is.EqualTo("Cabernet Reserve"));
        Assert.That(vino.Kategorija, Is.EqualTo(KategorijaVina.Premijum));
        Assert.That(vino.Zapremina, Is.EqualTo(0.75));
    }

    [Test]
    public void DatumFlasiranja_AutomatskiSePostavlja()
    {
        Vino vino = new Vino();
        Assert.That(vino.DatumFlasiranja, Is.EqualTo(DateTime.Now).Within(TimeSpan.FromSeconds(1)));
    }

    [Test]
    public void ToString_VracaDobarFormat()
    {
        Vino vino = new Vino
        {
            Naziv = "Test Vino",
            SifraSerije = "VN-2025-001",
            Kategorija = KategorijaVina.Kvalitetno,
            Zapremina = 1.5
        };

        string rezultat = vino.ToString();

        Assert.That(rezultat, Does.Contain("Test Vino"));
        Assert.That(rezultat, Does.Contain("VN-2025-001"));
        Assert.That(rezultat, Does.Contain("Kvalitetno"));
    }

    [Test]
    [TestCase(KategorijaVina.Stolno)]
    [TestCase(KategorijaVina.Kvalitetno)]
    [TestCase(KategorijaVina.Premijum)]
    public void Kategorija_MozeSePodesiti(KategorijaVina kategorija)
    {
        Vino vino = new Vino { Kategorija = kategorija };
        Assert.That(vino.Kategorija, Is.EqualTo(kategorija));
    }
}