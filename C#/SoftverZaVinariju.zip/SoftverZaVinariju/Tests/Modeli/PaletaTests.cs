﻿using Domain.Enumeracije;
using Domain.Modeli;
using NUnit.Framework;

[TestFixture]
public class PaletaTests
{
    [Test]
    public void Konstruktor_KreiraValidnuPaletu()
    {
        Paleta paleta = new Paleta
        {
            AdresaOdredista = "Beograd, Srbija",
            IdVinskogPodruma = "podrum-123",
            Status = StatusPalete.Upakovana
        };

        Assert.That(paleta, Is.Not.Null);
        Assert.That(paleta.AdresaOdredista, Is.EqualTo("Beograd, Srbija"));
        Assert.That(paleta.Status, Is.EqualTo(StatusPalete.Upakovana));
    }

    [Test]
    public void SpisakVinaIds_InicijalizujeSeSaPraznomListom()
    {
        Paleta paleta = new Paleta();
        Assert.That(paleta.SpisakVinaIds, Is.Not.Null);
        Assert.That(paleta.SpisakVinaIds, Is.Empty);
    }

    [Test]
    public void SpisakVinaIds_MozeDodatiVise()
    {
        Paleta paleta = new Paleta();
        paleta.SpisakVinaIds.Add("vino-1");
        paleta.SpisakVinaIds.Add("vino-2");

        Assert.That(paleta.SpisakVinaIds.Count, Is.EqualTo(2));
    }

    [Test]
    public void ToString_VracaDobarFormat()
    {
        Paleta paleta = new Paleta
        {
            Sifra = "PAL-001",
            AdresaOdredista = "Novi Sad",
            Status = StatusPalete.Otpremljena
        };

        string rezultat = paleta.ToString();

        Assert.That(rezultat, Does.Contain("PAL-001"));
        Assert.That(rezultat, Does.Contain("Novi Sad"));
        Assert.That(rezultat, Does.Contain("Otpremljena"));
    }

    [Test]
    public void Sifra_AutomatskiSeGenerise()
    {
        Paleta paleta1 = new Paleta();
        Paleta paleta2 = new Paleta();

        Assert.That(paleta1.Sifra, Is.Not.EqualTo(paleta2.Sifra));
    }
}