﻿using Domain.Modeli;

namespace Domain.Repozitorijumi
{
    public interface IFakturaRepozitorijum
    {
        bool Sacuvaj(Faktura faktura);
        IEnumerable<Faktura> PreuzmiSve();
        public Faktura DodajVino(Faktura fakt, Vino vino, int kolicina, double cena);
    }
}
