﻿using Domain.Modeli;

namespace Domain.Repozitorijumi
{
    public interface ILozaRepozitorijum
    {
        void Dodaj(Loza loza);
        Loza PreuzmiSaId(string id);
        void Azuriraj(string lozaId);
        IEnumerable<Loza> PreuzmiSve();
    }
}