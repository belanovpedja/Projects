﻿using Domain.Modeli;

namespace Domain.Repozitorijumi
{
    public interface IPaletaRepozitorijum
    {
        void Dodaj(Paleta paleta);
        IEnumerable<Paleta> PreuzmiSve();
        void Azuriraj(Paleta paleta);
    }
}