﻿using Domain.Modeli;

namespace Domain.Repozitorijumi
{
    public interface IVinoRepozitorijum
    {
        void Dodaj(Vino vino);
        IEnumerable<Vino> PreuzmiSve();
        Vino PreuzmiSaId(string id);
    }
}