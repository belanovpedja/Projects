﻿using Domain.Modeli;

namespace Domain.Repozitorijumi
{
    public interface IPodrumRepozitorijum
    {
        void Dodaj(VinskiPodrum podrum);
        IEnumerable<VinskiPodrum> PreuzmiSve();
    }
}