﻿using Domain.Enumeracije;
using Domain.Modeli;

namespace Domain.Servisi
{
    public interface IProdajaServis
    {
        Faktura ProcesuirajProdaju(TipProdaje tip, NacinPlacanja nacin, Dictionary<string, int> stavke);
        IEnumerable<Faktura> PreuzmiSveFakture();
        Faktura DodajVinaUFakturu(Faktura f, Vino vino, int kolicina, double cena);
        Faktura ObradiKupovinu(string vinoID, int kolicina, double cena);
    }
}
