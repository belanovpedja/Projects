﻿using Domain.Enumeracije;
using Domain.Modeli;

namespace Domain.Servisi
{
    public interface IVinogradarstvoServis
    {
        void EvidentirajLozu(string naziv, double secer, int godina, string region, FazaZrelosti faza);
        Loza PosadiNovuLozu(string naziv, string region);
        bool PromeniNivoSecera(string lozaId, double noviNivo);
        IEnumerable<Loza> PregledSvihLoza();
        public (IEnumerable<Loza>, int) ObratiLoze(string nazivSorte, int brojLoza);
    }
}