﻿using Domain.Modeli;

namespace Domain.Servisi
{
    public interface ISkladistenjeServis
    {
        void EvidentirajPodrum(string naziv, double temperatura, int kapacitet);
        IEnumerable<VinskiPodrum> PregledPodruma();
        IEnumerable<Paleta> IsporuciPalete(int brojPaleta);
    }
}