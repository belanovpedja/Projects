﻿using Domain.Enumeracije;
using Domain.Modeli;

namespace Domain.Servisi
{
    public interface IProizvodnjaVinaServis
    {
        void EvidentirajVino(string naziv, KategorijaVina kategorija, double zapremina, string idLoze);

        public IEnumerable<Vino> PokreniFermentaciju(string nazivVina, KategorijaVina kategorija, int brojFlasa, ZapreminaFlase zapremina, string nazivLoze, string region);


        IEnumerable<Vino> PregledSvihVina();
    }
}