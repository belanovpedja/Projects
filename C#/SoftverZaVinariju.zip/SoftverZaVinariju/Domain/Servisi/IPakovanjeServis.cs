﻿using Domain.Modeli;

namespace Domain.Servisi
{
    public interface IPakovanjeServis
    {
        (bool, string) KreirajPaletu(string adresa, string idPodruma, List<string> vinaIds);

        (bool, string) OtpremiPaletu(string sifraPalete, string idPodruma);

        IEnumerable<Paleta> PregledPaleta();
        IEnumerable<Vino> Raspakuj(Paleta paleta);
        public void DelegirajFermentacijuBuraz(string vinoID, int brojFlasa);
    }
}