﻿namespace Domain.BazaPodataka
{
    public interface IBazaPodataka
    {
        TabeleBazaPodataka Tabele { get; }
        bool SacuvajSve();
        void UcitajSve();
    }
}
