﻿namespace Domain.Enumeracije
{
    public enum StatusPalete
    {
        Upakovana,
        Otpremljena
    }
}