﻿namespace Domain.Enumeracije
{
    public enum NacinPlacanja
    {
        Gotovina,
        Predracun,
        GotovinskiRacun
    }
}
