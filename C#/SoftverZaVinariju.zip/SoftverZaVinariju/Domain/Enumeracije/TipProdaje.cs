﻿namespace Domain.Enumeracije
{
    public enum TipProdaje
    {
        Restoranska,
        DiskontPica
    }
}
