﻿namespace Domain.Enumeracije
{
    public enum ZapreminaFlase
    {
        Mala,   // 0.75 L
        Velika  // 1.5 L
    }
}
