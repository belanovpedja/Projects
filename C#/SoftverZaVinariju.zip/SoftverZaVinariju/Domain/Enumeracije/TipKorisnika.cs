﻿namespace Domain.Enumeracije
{
    public enum TipKorisnika
    {
        Admin,
        GlavniEnolog,
        Kelar
    }
}
