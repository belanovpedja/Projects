﻿namespace Domain.Enumeracije
{
    public enum KategorijaVina
    {
        Stolno,
        Kvalitetno,
        Premijum
    }
}