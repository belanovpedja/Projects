﻿namespace Domain.Enumeracije
{
    public enum TipEvidencije
    {
        INFO,
        ERROR,
        WARNING
    }
}
