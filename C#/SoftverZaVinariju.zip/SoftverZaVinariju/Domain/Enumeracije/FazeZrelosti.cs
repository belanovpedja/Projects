﻿namespace Domain.Enumeracije
{
    public enum FazaZrelosti
    {
        Posadjena,
        Cveta,
        Zrenje,
        SpremnaZaBerbu,
        Obrana
    }
}