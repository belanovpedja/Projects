﻿namespace Domain.Konstante
{
    public static class VremeKonstante
    {
        public const int VINSKI_PODRUM_TRAJANJE = 300;
        public const int LOKALNI_KELAR_TRAJANJE = 1800;
    }
}
