﻿namespace Domain.Konstante
{
    public static class KolicinaKonstante
    {
        public const int VINSKI_PODRUM_PALETA = 5;
        public const int LOKALNI_KELAR_PALETA = 2;
    }
}




