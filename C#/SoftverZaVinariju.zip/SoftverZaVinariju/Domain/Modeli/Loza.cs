﻿using Domain.Enumeracije;

namespace Domain.Modeli
{
    public class Loza
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Naziv { get; set; } = string.Empty;
        public double NivoSecera { get; set; } // 15.0 - 28.0 Brix
        public int GodinaSadnje { get; set; }
        public string Region { get; set; } = string.Empty;
        public FazaZrelosti Faza { get; set; }

        public override string ToString()
        {
            return $"{Naziv} ({Region}, {GodinaSadnje}) - {Faza} - Šećer: {NivoSecera}";
        }
    }
}