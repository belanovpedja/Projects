﻿namespace Domain.Modeli
{
    public class StavkaFakture
    {
        public string NazivVina { get; set; } = "";
        public int Kolicina { get; set; }
        public double CenaPoKomadu { get; set; }
        public double Ukupno => Kolicina * CenaPoKomadu;
    }
}
