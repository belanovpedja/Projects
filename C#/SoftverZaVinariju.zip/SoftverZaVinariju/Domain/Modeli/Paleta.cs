﻿using Domain.Enumeracije;

namespace Domain.Modeli
{
    public class Paleta
    {
        public string Sifra { get; set; } = Guid.NewGuid().ToString();
        public string AdresaOdredista { get; set; } = string.Empty;
        public string IdVinskogPodruma { get; set; } = string.Empty;
        public List<string> SpisakVinaIds { get; set; } = new List<string>();
        public StatusPalete Status { get; set; }

        public override string ToString()
        {
            return $"Paleta {Sifra} -> {AdresaOdredista} ({Status})";
        }
    }
}