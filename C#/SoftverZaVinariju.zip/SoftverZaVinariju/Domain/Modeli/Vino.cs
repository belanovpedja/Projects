﻿using Domain.Enumeracije;

namespace Domain.Modeli
{
    public class Vino
    {
        // ID se formira po sablonu VN-2025-ID_VINA u servisu ili konstruktoru
        public string SifraSerije { get; set; } = string.Empty;
        public string Naziv { get; set; } = string.Empty;
        public KategorijaVina Kategorija { get; set; }
        public double Zapremina { get; set; }
        public string IdLoze { get; set; } = string.Empty; // Veza sa lozom
        public DateTime DatumFlasiranja { get; set; } = DateTime.Now;

        public override string ToString()
        {
            return $"{Naziv} [{SifraSerije}] - {Kategorija} ({Zapremina}L)"; 
        }
    }
}