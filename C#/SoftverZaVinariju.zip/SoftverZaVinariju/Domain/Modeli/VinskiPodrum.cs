﻿namespace Domain.Modeli
{
    public class VinskiPodrum
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Naziv { get; set; } = string.Empty;
        public double Temperatura { get; set; }
        public int MaksimalniKapacitetPaleta { get; set; }

        public override string ToString()
        {
            return $"{Naziv} (Temp: {Temperatura}C, Kapacitet: {MaksimalniKapacitetPaleta})";
        }
    }
}