﻿using Domain.Enumeracije;

namespace Domain.Modeli
{
    public class Faktura
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public TipProdaje Tip { get; set; }
        public NacinPlacanja Placanje { get; set; }
        public List<StavkaFakture> Stavke { get; set; } = new List<StavkaFakture>();
        public double UkupanIznos { get; set; }
        public DateTime Datum { get; set; } = DateTime.Now;
    }
}
