﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Servisi;

namespace Presentation.Kelar
{
    public class KelarMeni
    {
        private readonly IProdajaServis _prodajaServis;
        private readonly IVinogradarstvoServis _vinogradarstvoServis;
        private readonly IPakovanjeServis _pakovanjeServis;
        private readonly IProizvodnjaVinaServis _vinoServis;
        private readonly ISkladistenjeServis _skladisteServis;

        public KelarMeni(IProdajaServis prodajaServis, IVinogradarstvoServis vinogradarstvoServis, IPakovanjeServis pakovanjeServis, IProizvodnjaVinaServis vinoServis, ISkladistenjeServis skladisteServis)
        {
            _prodajaServis = prodajaServis;
            _vinogradarstvoServis = vinogradarstvoServis;
            _pakovanjeServis = pakovanjeServis;
            _vinoServis = vinoServis;
            _skladisteServis = skladisteServis;
        }

        public void Prikazi()
        {
            bool nazad = false;
            while (!nazad)
            {
                Console.Clear();
                Console.WriteLine("=== KELAR MAJSTOR - MENI ===");
                Console.WriteLine("1. Nova prodaja/Faktura");
                Console.WriteLine("2. Evidencija vinove loze");
                Console.WriteLine("3. Kreiranje palete");
                Console.WriteLine("4. Sađenje vinove loze");
                Console.WriteLine("5. Berba vinove loze");
                Console.WriteLine("6. Prikaži katalog vina");
                Console.WriteLine("0. Kraj");

                Console.Write("Izbor: ");

                string izbor = Console.ReadLine() ?? "";

                switch (izbor)
                {
                    case "1": RadSaFakturom(); break;
                    case "2": EvidencijaLoze(); break;
                    case "3": KreiranjePalete(); break;
                    case "4": SadjenjeLoze(); break;
                    case "5": BerbaLoze(); break;
                    case "6": PrikaziKatalogVina(); break;
                    case "0": nazad = true; break;
                    default: Console.WriteLine("Nepoznata opcija."); Console.ReadKey(); break;
                }
            }
        }


        private void RadSaFakturom()
        {
            Console.WriteLine("\n--- NOVA FAKTURA ---");
            Console.WriteLine("Tip prodaje (0-Restoranska, 1-Diskont): ");
            TipProdaje tip = (TipProdaje)int.Parse(Console.ReadLine() ?? "0");

            Console.WriteLine("Način plaćanja (0-Gotovina, 1-Predracun, 2-Gotovinski): ");
            NacinPlacanja nacin = (NacinPlacanja)int.Parse(Console.ReadLine() ?? "0");

            Dictionary<string, int> narudzbina = new Dictionary<string, int>();
            while (true)
            {
                Console.Write("Unesite naziv vina (ili 'kraj'): ");
                string naziv = Console.ReadLine() ?? "";
                if (naziv.ToLower() == "kraj") break;

                Console.Write("Količina: ");
                if (int.TryParse(Console.ReadLine(), out int kol))
                {
                    if (narudzbina.ContainsKey(naziv))
                        narudzbina[naziv] += kol;
                    else
                        narudzbina.Add(naziv, kol);
                }
            }

            if (narudzbina.Count > 0)
            {
                Faktura f = _prodajaServis.ProcesuirajProdaju(tip, nacin, narudzbina);
                Console.WriteLine($"Faktura {f.Id} uspešno kreirana! Iznos: {f.UkupanIznos}");
            }
            Console.ReadKey();
        }

        private void EvidencijaLoze()
        {
            Console.WriteLine("\n--- EVIDENCIJA LOZE ---");
            Console.Write("Naziv loze: ");
            string? naziv = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(naziv))
            {
                Console.WriteLine("Naziv loze ne može biti prazan.");
                return;
            }

            Console.Write("Nivo šećera (15.0 - 28.0): ");
            double secer = double.Parse(Console.ReadLine() ?? "0");

            Console.Write("Godina sadnje: ");
            int godina = int.Parse(Console.ReadLine() ?? "2024");

            Console.Write("Region: ");
            string? region = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(region))
            {
                Console.WriteLine("Region ne može biti prazan.");
                return;
            }

            Console.WriteLine("Faza zrelosti (0-Posadjena, 1-Cveta, 2-Zrenje, 3-Spremna, 4-Obrana): ");
            FazaZrelosti faza = (FazaZrelosti)int.Parse(Console.ReadLine() ?? "0");

            _vinogradarstvoServis.EvidentirajLozu(naziv, secer, godina, region, faza);
            Console.WriteLine("Loza uspešno evidentirana!");
            Console.ReadKey();
        }

        private void SadjenjeLoze()
        {
            Console.WriteLine("\n--- SAĐJENJE LOZE---");
            Console.WriteLine("\n(Nivo šećera bice generisan automatski)");

            Console.Write("Naziv loze: ");
            string? naziv = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(naziv))
            {
                Console.WriteLine("Naziv loze ne može biti prazan.");
                return;
            }

            Console.Write("Region: ");
            string? region = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(region))
            {
                Console.WriteLine("Region ne može biti prazan.");
                return;
            }

            Loza loza = _vinogradarstvoServis.PosadiNovuLozu(naziv, region);

            IEnumerable<Loza> sveLoze = _vinogradarstvoServis.PregledSvihLoza();
            if (!sveLoze.Contains(loza))
            {
                Console.WriteLine("Greška pri sadnji loze.");
            }
            else
            {
                Console.WriteLine($"Loza uspešno posađena! ID: {loza.Id}, Nivo šećera: {loza.NivoSecera}");
            }
            Console.ReadKey();
        }

        private void KreiranjePalete()
        {
            Console.WriteLine("\n--- KREIRANJE PALETE ---");
            Console.Write("Adresa odredišta: ");
            string adresa = Console.ReadLine() ?? "";

            Console.WriteLine("\nDostupni podrumi:");
            IEnumerable<VinskiPodrum> podrumi = _skladisteServis.PregledPodruma();
            if (!podrumi.Any())
            {
                Console.WriteLine("GREŠKA: Nema evidentianih vinskih podruma u sistemu.");
                Console.ReadKey();
                return;
            }

            foreach (var p in podrumi)
            {
                Console.WriteLine($"ID: {p.Id} | {p.Naziv} (Temp: {p.Temperatura}C, Kapacitet: {p.MaksimalniKapacitetPaleta})");
            }

            Console.Write("\nUnesite ID podruma: ");
            string idPodruma = Console.ReadLine() ?? "";

            IEnumerable<Vino> svaVina = _vinoServis.PregledSvihVina();
            List<string> zauzetaVinaIds = _pakovanjeServis.PregledPaleta().SelectMany(p => p.SpisakVinaIds).ToList();

            List<Vino> dostupnaVina = svaVina.Where(v => !zauzetaVinaIds.Contains(v.SifraSerije)).ToList();

            if (!dostupnaVina.Any())
            {
                Console.WriteLine("\nGREŠKA: Nema dostupnih (nespakovanih) vina za pakovanje.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("\nDostupna vina:");
            foreach (Vino v in dostupnaVina)
            {
                Console.WriteLine($"Šifra: {v.SifraSerije} | {v.Naziv} ({v.Kategorija}, {v.Zapremina}L)");
            }

            List<string> vinaIds = new List<string>();
            while (true)
            {
                Console.Write("\nUnesite šifru serije vina za dodavanje u paletu (ili 'kraj'): ");
                string unos = Console.ReadLine() ?? "";

                if (unos.ToLower() == "kraj")
                {
                    if (vinaIds.Count == 0)
                    {
                        Console.WriteLine("UPOZORENJE: Morate dodati bar jedno vino u paletu.");
                        continue;
                    }
                    break;
                }

                if (vinaIds.Contains(unos))
                {
                    Console.WriteLine("UPOZORENJE: Ovo vino je vec dodato u paletu.");
                    continue;
                }

                if (!dostupnaVina.Any(v => v.SifraSerije == unos))
                {
                    Console.WriteLine("GREŠKA: Vino sa tom šifrom nije dostupno ili ne postoji.");
                    continue;
                }

                vinaIds.Add(unos);
                Console.WriteLine($"Vino {unos} dodato. Ukupno vina u paleti: {vinaIds.Count}");
            }

            (bool uspeh, string poruka) = _pakovanjeServis.KreirajPaletu(adresa, idPodruma, vinaIds);

            Console.WriteLine($"\n{poruka}");
            Console.ReadKey();
        }

        private void BerbaLoze()
        {
            Console.WriteLine("\n--- BERBA LOZE ---");

            Console.Write("Unesite naziv sorte: ");
            string naziv = Console.ReadLine() ?? "";

            Console.Write("Unesite broj loza za berbu: ");
            int broj = int.TryParse(Console.ReadLine(), out int b) ? b : 0;

            (var obraneLoze, _) = _vinogradarstvoServis.ObratiLoze(naziv, broj);

            if (!obraneLoze.Any())
            {
                Console.WriteLine("Nema dovoljno loza spremnih za berbu.");
            }
            else
            {
                Console.WriteLine($"Uspešno obrano {obraneLoze.Count()} loza sorte {naziv}:");
                foreach (var loza in obraneLoze)
                {
                    Console.WriteLine($"- ID: {loza.Id}, Šećer: {loza.NivoSecera}");
                }

                Console.WriteLine("Grožđe je spremno za fermentaciju.");
            }

            Console.ReadKey();
        }
        private void PrikaziKatalogVina()
        {
            Console.WriteLine("\n--- KATALOG DOSTUPNIH VINA ---");

            var vina = _vinoServis.PregledSvihVina().ToList();

            if (!vina.Any())
            {
                Console.WriteLine("Trenutno nema dostupnih vina.");
            }
            else
            {
                foreach (var vino in vina)
                {
                    Console.WriteLine(vino); // da se ne zbunite ovo ce manuelno pozvati override ToString() metodu koja je definisana u klasi vino
                }
            }

            Console.ReadKey();
        }

    }


}