﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Servisi;

namespace Presentation.Authentifikacija
{
    public class AutentifikacioniMeni
    {
        private readonly IAutentifikacijaServis autentifikacijaServis;

        public AutentifikacioniMeni(IAutentifikacijaServis autentifikacijaServis)
        {
            this.autentifikacijaServis = autentifikacijaServis;
        }

        public bool TryLogin(out Korisnik korisnik)
        {
            korisnik = new Korisnik();
            bool uspesnaPrijava = false;
            string? korisnickoIme = "", lozinka = "";

            Console.Write("Korisničko ime: ");
            korisnickoIme = Console.ReadLine() ?? "";

            Console.Write("Lozinka: ");
            lozinka = Console.ReadLine() ?? "";

            (uspesnaPrijava, korisnik) = autentifikacijaServis.Prijava(korisnickoIme.Trim(), lozinka.Trim());

            return uspesnaPrijava;
        }

        public bool Register(out Korisnik korisnik)
        {
            korisnik = new Korisnik();

            Console.Write("Korisničko ime: ");
            string korisnickoIme = (Console.ReadLine() ?? "").Trim();

            Console.Write("Ime: ");
            string ime = (Console.ReadLine() ?? "").Trim();

            Console.Write("Prezime: ");
            string prezime = (Console.ReadLine() ?? "").Trim();

            Console.Write("Lozinka: ");
            string lozinka = (Console.ReadLine() ?? "").Trim();

            string ulogaUnos;
            while (true)
            {
                Console.Write("Uloga (Enolog/Kelar): ");
                ulogaUnos = Console.ReadLine() ?? "";
                if (ulogaUnos == "Enolog" || ulogaUnos == "Kelar")
                    break;
                Console.WriteLine("Nevažeći unos. Unesite 'Enolog' ili 'Kelar'.");
            }

            TipKorisnika uloga = ulogaUnos == "Enolog" ? TipKorisnika.GlavniEnolog : TipKorisnika.Kelar;

            Korisnik noviKorisnik = new Korisnik(korisnickoIme, lozinka, ime, prezime, uloga);

            (bool registracijaUspela, Korisnik? registrovani) = autentifikacijaServis.Registracija(noviKorisnik);

            if (!registracijaUspela)
            {
                korisnik = new Korisnik();
                return false;
            }

            (bool prijavaUspela, Korisnik? prijavljeniKorisnik) = autentifikacijaServis.Prijava(korisnickoIme, lozinka);

            if (!prijavaUspela)
            {
                korisnik = new Korisnik();
                return false;
            }

            korisnik = prijavljeniKorisnik;
            return true;
        }
    }
}