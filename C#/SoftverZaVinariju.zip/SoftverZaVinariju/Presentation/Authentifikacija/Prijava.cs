﻿using Domain.Modeli;
using Domain.Servisi;

namespace Presentation.Authentifikacija
{
    public class PrijavaMeni
    {
        private readonly IAutentifikacijaServis _autentifikacijaServis;

        public PrijavaMeni(IAutentifikacijaServis autentifikacijaServis)
        {
            _autentifikacijaServis = autentifikacijaServis;
        }

        public Korisnik PrikaziOpcije()
        {
            bool nazad = false;
            Korisnik korisnik = new Korisnik();

            while (!nazad)
            {
                Console.WriteLine("============= Prijava Meni =============");
                Console.WriteLine("1. Prijava");
                Console.WriteLine("2. Registracija");
                Console.WriteLine("0. Izlaz");

                int opcija;
                if (!int.TryParse(Console.ReadLine(), out opcija)) opcija = 0;
                AutentifikacioniMeni am = new AutentifikacioniMeni(_autentifikacijaServis);

                switch (opcija)
                {
                    case 1:
                        while (am.TryLogin(out korisnik) == false)
                        {
                            Console.WriteLine("Pogrešno korisničko ime ili lozinka. Pokušajte ponovo.");
                        }
                        return korisnik;
                    case 2:
                        while (am.Register(out korisnik) == false)
                        {
                            Console.WriteLine("Korisnik sa datim korisničkim imenom već postoji.");
                        }
                        return korisnik;
                    case 0:
                        Console.WriteLine("Izlaz iz aplikacije.");
                        nazad = true;
                        break;
                    default:
                        Console.WriteLine("Nepoznata opcija. Pokušajte ponovo.");
                        break;
                }
            }

            return korisnik;
        }
    }
}