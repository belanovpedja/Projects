﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Servisi;

namespace Presentation.Enolog
{
    public class EnologMeni
    {
        private readonly IProdajaServis _prodajaServis;
        private readonly IProizvodnjaVinaServis _proizvodnjaServis;
        private readonly ISkladistenjeServis _skladistenjeServis;
        private readonly IVinogradarstvoServis _vinogradarstvoServis;
        private readonly IPakovanjeServis _pakovanjeServis;

        public EnologMeni(IProdajaServis prodajaServis, IProizvodnjaVinaServis proizvodnjaServis, ISkladistenjeServis skladistenjeServis, IVinogradarstvoServis vinogradarstvoServis, IPakovanjeServis pakovanjeServis)
        {
            _prodajaServis = prodajaServis;
            _proizvodnjaServis = proizvodnjaServis;
            _skladistenjeServis = skladistenjeServis;
            _vinogradarstvoServis = vinogradarstvoServis;
            _pakovanjeServis = pakovanjeServis;
        }

        public void Prikazi()
        {
            bool nazad = false;
            while (!nazad)
            {
                Console.Clear();
                Console.WriteLine("=== GLAVNI ENOLOG - MENI ===");
                Console.WriteLine("1. Pregled faktura");
                Console.WriteLine("2. Evidencija proizvodnje vina");
                Console.WriteLine("3. Evidencija vinskih podruma");
                //da li tu prikazati samo sta pise u zad i kod KELARA isto
                Console.WriteLine("4. Promena nivoa šećera u grožđu");
                Console.WriteLine("5. Pokretanje fermentacije novog vina");

                /*
                 * 
                 * Сервис продаје на основу понуде купцу нуди сва доступна пецива. Купац бира
жељену количину пецива након чега се пецива продају. Осим продаје пецива,
сервис главном пекару нуди и преглед свих продатих пецива.



                 *  switch (opcija[0])
                {
                    case '1':
                        VrstaPeciva randomVrsta = (VrstaPeciva)(new Random().Next(0, 3));
                        int randomKomada = new Random().Next(1, 21);
                        var peciva = prodajaServis.ProdajaPeciva(randomVrsta, randomKomada);
                        Console.WriteLine($"Prodato je {peciva.Count()} peciva tipa {randomVrsta}.");
                        break;
                    case '2':
                        if (korisnik.Uloga != TipKorisnika.GLAVNI_PEKAR)
                        {
                            Console.WriteLine("Nemate dozvolu za ovu opciju!\n");
                            break;
                        }
                        PregledProdatihPeciva();
                        break;
                    case '3':
                        kraj = true;
                        break;
                    default:
                        continue;
                 */
                Console.WriteLine("6. Berba loze");
                Console.WriteLine("7. Otpremanje palete");
                Console.WriteLine("8. Obrada kupovine");
                Console.WriteLine("0. Kraj");
                Console.Write("Izbor: ");

                string izbor = Console.ReadLine() ?? "";

                switch (izbor)
                {
                    case "1": PrikaziFakture(); break;
                    case "2": EvidencijaVina(); break;
                    case "3": EvidencijaPodruma(); break;
                    case "4": PromenaNivoaSecera(); break;
                    case "5": PokreniFermentaciju(); break;
                    case "6": BerbaLoze(); break;
                    case "7": OtpremanjePalete(); break;
                    case "8": ObradaKupovine(); break;
                    case "0": nazad = true; break;
                    default: Console.WriteLine("Nepoznata opcija."); Console.ReadKey(); break;
                }
            }
        }

        private void ObradaKupovine()
        {
            Console.WriteLine("\n--- OBRADA KUPOVINE ---");

            Console.WriteLine("Dostupna vina:");
            foreach (Vino v in _proizvodnjaServis.PregledSvihVina())
            {
                Console.WriteLine($"ID: {v.SifraSerije} | Naziv: {v.Naziv} | Kategorija: {v.Kategorija} | Zapremina: {v.Zapremina}L");
            }

            Console.Write("Unesite ID vina: ");
            string vinoID = Console.ReadLine() ?? "";

            if (vinoID == "")
            {
                Console.WriteLine("ID vina ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            Console.Write("Unesite količinu: ");
            int kolicina;
            int.TryParse(Console.ReadLine() ?? "-1", out kolicina);

            if (kolicina <= 0)
            {
                Console.WriteLine("Količina mora biti veća od nule.");
                Console.ReadKey();
                return;
            }

            Console.Write("Unesite cenu po flaši: ");
            double cena;
            double.TryParse(Console.ReadLine() ?? "-1", out cena);

            if (cena <= 0)
            {
                Console.WriteLine("Cena mora biti veća od nule.");
                Console.ReadKey();
                return;
            }

            Faktura faktura = _prodajaServis.ObradiKupovinu(vinoID, kolicina, cena);

            if (string.IsNullOrEmpty(faktura.Id))
            {
                Console.WriteLine("Greška pri obradi kupovine.");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine($"Kupovina uspešno obrađena. Faktura ID: {faktura.Id}");
                Console.ReadKey();
            }
        }

        public void PokreniFermentaciju()
        {
            Console.WriteLine("Naziv unesi:");
            string? nazivVina = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(nazivVina))
            {
                Console.WriteLine("Naziv vina ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Unesi kategoriju vina:");
            string? kategorijaInput = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(kategorijaInput) || !Enum.TryParse(typeof(KategorijaVina), kategorijaInput, out var kategorijaObj))
            {
                Console.WriteLine("Neispravna kategorija vina.");
                Console.ReadKey();
                return;
            }
            var kategorija = (KategorijaVina)kategorijaObj;

            Console.WriteLine("Broj flaša:");
            string? brojFlasaInput = Console.ReadLine();
            if (!int.TryParse(brojFlasaInput, out int brojFlasa))
            {
                Console.WriteLine("Neispravan broj flaša.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Unesi zapreminu flaše:");
            string? zapreminaInput = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(zapreminaInput) || !Enum.TryParse(typeof(ZapreminaFlase), zapreminaInput, out var zapreminaObj))
            {
                Console.WriteLine("Neispravna zapremina flaše.");
                Console.ReadKey();
                return;
            }
            var zapremina = (ZapreminaFlase)zapreminaObj;

            Console.WriteLine("Naziv loze:");
            string? nazivLoze = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(nazivLoze))
            {
                Console.WriteLine("Naziv loze ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Naziv region:");
            string? region = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(region))
            {
                Console.WriteLine("Naziv regiona ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            var vina = _proizvodnjaServis.PokreniFermentaciju(nazivVina, kategorija, brojFlasa, zapremina, nazivLoze, region);

            Console.WriteLine($"Uspešno proizvedeno {vina.Count()} vina.");
            Console.ReadKey();
        }

        private void PrikaziFakture()
        {
            Console.WriteLine("\n--- PREGLED FAKTURA ---");
            foreach (Faktura f in _prodajaServis.PreuzmiSveFakture())
            {
                Console.WriteLine($"ID: {f.Id} | Iznos: {f.UkupanIznos} | Datum: {f.Datum}");

                foreach (StavkaFakture s in f.Stavke)
                {
                    Console.WriteLine($"\tVino: {s.NazivVina} | Količina: {s.Kolicina} | Cena po flaši: {s.CenaPoKomadu}");
                }
            }
            Console.ReadKey();
        }

        private void EvidencijaVina()
        {
            Console.WriteLine("\n--- EVIDENCIJA VINA ---");
            Console.Write("Naziv vina: ");
            string? naziv = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(naziv))
            {
                Console.WriteLine("Naziv vina ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Kategorija (0-Stolno, 1-Kvalitetno, 2-Premijum): ");
            string? katInput = Console.ReadLine();
            if (!int.TryParse(katInput, out int katInt))
            {
                Console.WriteLine("Neispravna kategorija.");
                Console.ReadKey();
                return;
            }
            KategorijaVina kat = (KategorijaVina)katInt;

            Console.Write("Zapremina (L): ");
            string? zapInput = Console.ReadLine();
            if (!double.TryParse(zapInput, out double zap))
            {
                Console.WriteLine("Neispravna zapremina.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Dostupne loze:");
            foreach (Loza l in _vinogradarstvoServis.PregledSvihLoza())
            {
                Console.WriteLine($"ID: {l.Id} | {l.Naziv}");
            }
            Console.Write("Unesite ID loze: ");
            string? idLoze = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(idLoze))
            {
                Console.WriteLine("ID loze ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            _proizvodnjaServis.EvidentirajVino(naziv, kat, zap, idLoze);
            Console.WriteLine("Vino uspešno evidentirano (Šifra generisana automatski)!");
            Console.ReadKey();
        }

        private void EvidencijaPodruma()
        {
            Console.WriteLine("\n--- EVIDENCIJA VINSKOG PODRUMA ---");
            Console.Write("Naziv podruma: ");
            string naziv = Console.ReadLine() ?? "";
            if (string.IsNullOrWhiteSpace(naziv))
            {
                Console.WriteLine("Naziv podruma ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            Console.Write("Temperatura skladištenja (C): ");
            double temp = double.Parse(Console.ReadLine() ?? "12");

            Console.Write("Maksimalni kapacitet paleta: ");
            int kap = int.Parse(Console.ReadLine() ?? "100");

            _skladistenjeServis.EvidentirajPodrum(naziv, temp, kap);
            Console.WriteLine("Podrum uspešno evidentiran!");
            Console.ReadKey();
        }

        private void PromenaNivoaSecera()
        {
            Console.WriteLine("\n--- IZMENA NIVOA ŠEĆERA U GROŽĐU ---");

            Console.WriteLine("\nDostupne loze:");
            foreach (Loza l in _vinogradarstvoServis.PregledSvihLoza())
            {
                Console.WriteLine($"ID: {l.Id} | {l.Naziv} | Secer: {l.NivoSecera} Brix | Faza: {l.Faza}");
            }

            Console.Write("\nUnesite ID loze: ");
            string lozaId = Console.ReadLine() ?? "";

            Console.Write("Unesite novi nivo secera (15.0-28.0 Brix): ");
            string noviNivoInput = Console.ReadLine() ?? "";

            if (!double.TryParse(noviNivoInput, out double noviNivo))
            {
                Console.WriteLine("Neispravan unos.");
                Console.ReadKey();
                return;
            }

            bool uspesno = _vinogradarstvoServis.PromeniNivoSecera(lozaId, noviNivo);

            if (uspesno)
            {
                Console.WriteLine("Nivo šećera uspešno promenjen!");
            }
            else
            {
                Console.WriteLine("Došlo je do greške pri promeni nivoa šećera.");
            }

            Console.ReadKey();
        }
        private void BerbaLoze()
        {
            Console.WriteLine("\n--- BERBA LOZE ---");

            Console.Write("Unesite naziv sorte: ");
            string? naziv = Console.ReadLine() ?? "";

            if (naziv == "")
            {
                Console.WriteLine("Naziv sorte ne može biti prazan.");
                Console.ReadKey();
                return;
            }

            Console.Write("Unesite broj loza za berbu: ");
            string brojInput = Console.ReadLine() ?? "";
            int broj = int.TryParse(brojInput, out int parsedBroj) ? parsedBroj : -1;

            if (broj <= 0)
            {
                Console.WriteLine("Neispravan broj loza za berbu.");
                Console.ReadKey();
                return;
            }

            (var obraneLoze, _) = _vinogradarstvoServis.ObratiLoze(naziv, broj);

            Console.WriteLine($"Uspešno obrano {obraneLoze.Count()} loza:");
            foreach (var loza in obraneLoze)
            {
                Console.WriteLine($"- ID: {loza.Id} | Šećer: {loza.NivoSecera}");
            }

            Console.WriteLine("\nGrožđe je spremno za fermentaciju.");

            Console.ReadKey();
        }

        private void OtpremanjePalete()
        {
            Console.WriteLine("\n--- OTPREMANJE PALETE ---");

            List<Paleta> upakovane = _pakovanjeServis.PregledPaleta().Where(p => p.Status == StatusPalete.Upakovana).ToList();

            if (!upakovane.Any())
            {
                Console.WriteLine("Nema upakovanih paleta spremnih za otpremu.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("\nUpakovane palete:");
            foreach (Paleta p in upakovane)
            {
                Console.WriteLine($"Šifra: {p.Sifra} | Adresa: {p.AdresaOdredista} | Broj vina: {p.SpisakVinaIds.Count}");
            }

            Console.Write("\nUnesite šifru palete: ");
            string sifra = Console.ReadLine() ?? "";

            Console.WriteLine("\nDostupni podrumi:");
            List<VinskiPodrum> podrumi = _skladistenjeServis.PregledPodruma().ToList();

            if (!podrumi.Any())
            {
                Console.WriteLine("GREŠKA: Nema evidentianih vinskih podruma u sistemu.");
                Console.ReadKey();
                return;
            }

            foreach (VinskiPodrum podrum in podrumi)
            {
                int brojPaletaUPodrumu = _pakovanjeServis.PregledPaleta().Count(p => p.IdVinskogPodruma == podrum.Id && p.Status == StatusPalete.Otpremljena);

                int slobodnihMesta = podrum.MaksimalniKapacitetPaleta - brojPaletaUPodrumu;

                Console.WriteLine($"ID: {podrum.Id} | {podrum.Naziv} " + $"(Kapacitet: {slobodnihMesta}/{podrum.MaksimalniKapacitetPaleta} slobodno)");
            }

            Console.Write("\nUnesite ID podruma: ");
            string idPodruma = Console.ReadLine() ?? "";

            (bool uspeh, string poruka) = _pakovanjeServis.OtpremiPaletu(sifra, idPodruma);

            Console.WriteLine($"\n{poruka}");
            Console.ReadKey();
        }
    }
}