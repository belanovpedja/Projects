﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.ProdajaServisi
{
    public class ProdajaServis : IProdajaServis
    {
        private readonly IFakturaRepozitorijum _repo;
        private readonly IVinoRepozitorijum _vinoRepozitorijum;
        private readonly ISkladistenjeServis _skladistenjeServis;
        private readonly IPakovanjeServis _pakovanjeServis;
        private readonly ILoggerServis _logger;
        private readonly TipKorisnika _ulogovanKorisnik;
        public ProdajaServis(IFakturaRepozitorijum repo, IVinoRepozitorijum vinoRepozitorijum, ISkladistenjeServis skladistenjeServis, IPakovanjeServis pakovanjeServis, ILoggerServis loggerServis, TipKorisnika ulogovanKorisnik)
        {
            _repo = repo;
            _vinoRepozitorijum = vinoRepozitorijum;
            _skladistenjeServis = skladistenjeServis;
            _pakovanjeServis = pakovanjeServis;
            _logger = loggerServis;
            _ulogovanKorisnik = ulogovanKorisnik;
        }

        public Faktura ProcesuirajProdaju(TipProdaje tip, NacinPlacanja nacin, Dictionary<string, int> narudzbina)
        {
            if (narudzbina == null || narudzbina.Count == 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Prazna narudžbina");
                return new Faktura();
            }

            Faktura novaFaktura = new Faktura { Tip = tip, Placanje = nacin };
            double suma = 0;

            foreach (KeyValuePair<string, int> s in narudzbina)
            {
                if (s.Value <= 0)
                {
                    _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Preskočena stavka {s.Key} - nevalidna količina: {s.Value}");
                    continue;
                }

                double cena; // Različite cene po tipu

                if (tip == TipProdaje.Restoranska)
                {
                    cena = 1200.0;
                }
                else
                {
                    cena = 850.0;
                }

                StavkaFakture stavka = new StavkaFakture
                {
                    NazivVina = s.Key,
                    Kolicina = s.Value,
                    CenaPoKomadu = cena
                };
                novaFaktura.Stavke.Add(stavka);
                suma += stavka.Ukupno;
            }

            if (novaFaktura.Stavke.Count == 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Faktura nema validnih stavki");
                return new Faktura();
            }

            novaFaktura.UkupanIznos = suma;

            if (!_repo.Sacuvaj(novaFaktura))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Neuspelo čuvanje fakture");
                return new Faktura();
            }

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Faktura {novaFaktura.Id} kreirana: {tip}, iznos: {suma} RSD, stavki: {novaFaktura.Stavke.Count}");

            return novaFaktura;
        }

        public IEnumerable<Faktura> PreuzmiSveFakture()
        {
            return _repo.PreuzmiSve();
        }

        public Faktura DodajVinaUFakturu(Faktura faktura, Vino vino, int kolicina, double cena)
        {
            if (faktura == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Faktura je null");
                return new Faktura();
            }

            if (vino == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Vino je null");
                return faktura;
            }

            if (kolicina <= 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Nevalidna količina: {kolicina}");
                return faktura;
            }

            StavkaFakture stavka = new StavkaFakture
            {
                NazivVina = vino.Naziv,
                Kolicina = kolicina,
                CenaPoKomadu = cena
            };

            faktura.Stavke.Add(stavka);
            faktura.UkupanIznos += stavka.Ukupno;

            return faktura;
        }

        public Faktura ObradiKupovinu(string vinoID, int kolicina, double cena)
        {
            if (string.IsNullOrWhiteSpace(vinoID))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Prazan ID vina");
                return new Faktura();
            }

            if (kolicina <= 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Količina mora biti veća od 0");
                return new Faktura();
            }

            IEnumerable<Vino> dostupnaVina = _vinoRepozitorijum.PreuzmiSve();
            if (kolicina > dostupnaVina.Count())  //Nemamo dovoljno vina na stanju
            {
                int brojFlasa = kolicina - dostupnaVina.Count();
                _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Nema dovoljno flaša na stanju. Delegiran zahtev za još {brojFlasa} flaša vina.");
                _pakovanjeServis.DelegirajFermentacijuBuraz(vinoID, brojFlasa);
            }
            Vino vino = _vinoRepozitorijum.PreuzmiSaId(vinoID);
            if (vino == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Vino je null");
                return new Faktura();
            }
            IEnumerable<Paleta> palete = null;
            if (_ulogovanKorisnik == TipKorisnika.GlavniEnolog)
            {
                palete = _skladistenjeServis.IsporuciPalete(5);
            }else if(_ulogovanKorisnik == TipKorisnika.Kelar)
            {
                palete = _skladistenjeServis.IsporuciPalete(2);
            }

            if (palete == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Nije moguće isporučiti palete!");
                return new Faktura();
            }

            int kolicinaUPaletama = 0;
            foreach (Paleta p in palete)
            {
                IEnumerable<Vino> vinaIzPalete =  _pakovanjeServis.Raspakuj(p);
                kolicinaUPaletama += vinaIzPalete.Count();
            }

            if(kolicinaUPaletama < kolicina)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Nije moguće isporučiti traženu količinu vina");
                return new Faktura();
            }

            Faktura faktura = new Faktura
            {
                Datum = DateTime.Now,
                Tip = TipProdaje.Restoranska,
                Placanje = NacinPlacanja.Gotovina
            };

            faktura = DodajVinaUFakturu(faktura, vino, kolicina, cena);

            if (!_repo.Sacuvaj(faktura))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Neuspelo čuvanje fakture");
                return new Faktura();
            }

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Obrađena kupovina: {kolicina}x {vino.Naziv}, faktura: {faktura.Id}");

            return faktura;
        }
    }
}
