﻿using Domain.Enumeracije;
using Domain.Servisi;

namespace Services.LoggerServis
{
    public class LoggerServis : ILoggerServis
    {
        private readonly string _putanjaDatoteke;
        private readonly object _lockObjekat = new object();

        public LoggerServis(string putanjaDatoteke = "events.log")
        {
            _putanjaDatoteke = putanjaDatoteke;

            if (!File.Exists(_putanjaDatoteke))
            {
                File.Create(_putanjaDatoteke).Close();
            }
        }

        public bool EvidentirajDogadjaj(TipEvidencije tip, string poruka)
        {
            if (string.IsNullOrWhiteSpace(poruka))
                return false;

            string vremeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string logLinija = $"[{vremeStamp}] [{tip}] {poruka}";

            lock (_lockObjekat)
            {
                try
                {
                    File.AppendAllLines(_putanjaDatoteke, [logLinija]);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }
    }
}