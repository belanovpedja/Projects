﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;

namespace Services.Inicijalizacija
{
    public class InicijalizacijaPodataka
    {
        private readonly IKorisniciRepozitorijum _korisniciRepo;
        private readonly ILozaRepozitorijum _lozaRepo;
        private readonly IVinoRepozitorijum _vinoRepo;
        private readonly IPodrumRepozitorijum _podrumRepo;

        public InicijalizacijaPodataka(IKorisniciRepozitorijum korisniciRepo, ILozaRepozitorijum lozaRepo, IVinoRepozitorijum vinoRepo, IPodrumRepozitorijum podrumRepo)
        {
            _korisniciRepo = korisniciRepo;
            _lozaRepo = lozaRepo;
            _vinoRepo = vinoRepo;
            _podrumRepo = podrumRepo;
        }

        public void InicijalizujPodatke()
        {
            if (_korisniciRepo.SviKorisnici().Any())
            {
                Console.WriteLine("Podaci vec postoje u sistemu.");
                return;
            }

            Console.WriteLine("Inicijalizacija testnih podataka...");

            InicijalizujKorisnike();
            InicijalizujLoze();
            InicijalizujVina();
            InicijalizujPodrume();

            Console.WriteLine("Testni podaci uspesno inicijalizovani!");
        }

        private void InicijalizujKorisnike()
        {
            Korisnik enolog = new Korisnik
            {
                KorisnickoIme = "enolog",
                Lozinka = "enolog123",
                Ime = "Marko",
                Prezime = "Petrovic",
                Uloga = TipKorisnika.GlavniEnolog
            };

            Korisnik kelar = new Korisnik
            {
                KorisnickoIme = "kelar",
                Lozinka = "kelar123",
                Ime = "Jovan",
                Prezime = "Jovanovic",
                Uloga = TipKorisnika.Kelar
            };

            _korisniciRepo.DodajKorisnika(enolog);
            _korisniciRepo.DodajKorisnika(kelar);

            Console.WriteLine("- Dodato 2 korisnika (enolog/enolog123, kelar/kelar123)");
        }

        private void InicijalizujLoze()
        {
            List<Loza> loze = new List<Loza>
            {
                new Loza
                {
                    Naziv = "Cabernet Sauvignon",
                    NivoSecera = 22.5,
                    GodinaSadnje = 2020,
                    Region = "Vrsac",
                    Faza = FazaZrelosti.SpremnaZaBerbu
                },
                new Loza
                {
                    Naziv = "Merlot",
                    NivoSecera = 21.8,
                    GodinaSadnje = 2019,
                    Region = "Negotinska Krajina",
                    Faza = FazaZrelosti.SpremnaZaBerbu
                },
                new Loza
                {
                    Naziv = "Chardonnay",
                    NivoSecera = 20.3,
                    GodinaSadnje = 2021,
                    Region = "Sremski Karlovci",
                    Faza = FazaZrelosti.Zrenje
                },
                new Loza
                {
                    Naziv = "Pinot Noir",
                    NivoSecera = 23.1,
                    GodinaSadnje = 2018,
                    Region = "Zupa",
                    Faza = FazaZrelosti.SpremnaZaBerbu
                },
                new Loza
                {
                    Naziv = "Sauvignon Blanc",
                    NivoSecera = 19.7,
                    GodinaSadnje = 2022,
                    Region = "Fruska Gora",
                    Faza = FazaZrelosti.Cveta
                },
                new Loza
                {
                    Naziv = "Cabernet Sauvignon",
                    NivoSecera = 23.8,
                    GodinaSadnje = 2019,
                    Region = "Vrsac",
                    Faza = FazaZrelosti.SpremnaZaBerbu
                },
                new Loza
                {
                    Naziv = "Merlot",
                    NivoSecera = 22.0,
                    GodinaSadnje = 2020,
                    Region = "Negotinska Krajina",
                    Faza = FazaZrelosti.SpremnaZaBerbu
                },
                new Loza
                {
                    Naziv = "Riesling",
                    NivoSecera = 18.5,
                    GodinaSadnje = 2021,
                    Region = "Subotica",
                    Faza = FazaZrelosti.Posadjena
                }
            };

            foreach (Loza loza in loze)
            {
                _lozaRepo.Dodaj(loza);
            }

            Console.WriteLine($"- Dodato {loze.Count} loza");
        }

        private void InicijalizujVina()
        {
            List<string> lozaIds = _lozaRepo.PreuzmiSve().Select(l => l.Id).ToList();

            if (!lozaIds.Any())
            {
                Console.WriteLine("! Nije moguce kreirati vina - nema loza u sistemu");
                return;
            }

            List<Vino> vina = new List<Vino>
            {
                new Vino
                {
                    SifraSerije = $"VN-2025-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Naziv = "Cabernet Reserve",
                    Kategorija = KategorijaVina.Premijum,
                    Zapremina = 0.75,
                    IdLoze = lozaIds[0],
                    DatumFlasiranja = DateTime.Now.AddMonths(-3)
                },
                new Vino
                {
                    SifraSerije = $"VN-2025-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Naziv = "Merlot Classic",
                    Kategorija = KategorijaVina.Kvalitetno,
                    Zapremina = 0.75,
                    IdLoze = lozaIds[1 % lozaIds.Count],
                    DatumFlasiranja = DateTime.Now.AddMonths(-2)
                },
                new Vino
                {
                    SifraSerije = $"VN-2025-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Naziv = "Chardonnay Premium",
                    Kategorija = KategorijaVina.Premijum,
                    Zapremina = 1.5,
                    IdLoze = lozaIds[2 % lozaIds.Count],
                    DatumFlasiranja = DateTime.Now.AddMonths(-1)
                },
                new Vino
                {
                    SifraSerije = $"VN-2025-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Naziv = "Pinot Selection",
                    Kategorija = KategorijaVina.Kvalitetno,
                    Zapremina = 0.75,
                    IdLoze = lozaIds[3 % lozaIds.Count],
                    DatumFlasiranja = DateTime.Now.AddDays(-45)
                },
                new Vino
                {
                    SifraSerije = $"VN-2025-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Naziv = "House Red",
                    Kategorija = KategorijaVina.Stolno,
                    Zapremina = 0.75,
                    IdLoze = lozaIds[0],
                    DatumFlasiranja = DateTime.Now.AddDays(-30)
                },
                new Vino
                {
                    SifraSerije = $"VN-2025-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Naziv = "House White",
                    Kategorija = KategorijaVina.Stolno,
                    Zapremina = 0.75,
                    IdLoze = lozaIds[2 % lozaIds.Count],
                    DatumFlasiranja = DateTime.Now.AddDays(-20)
                }
            };

            foreach (Vino vino in vina)
            {
                _vinoRepo.Dodaj(vino);
            }

            Console.WriteLine($"- Dodato {vina.Count} vina");
        }

        private void InicijalizujPodrume()
        {
            List<VinskiPodrum> podrumi = new List<VinskiPodrum>
            {
                new VinskiPodrum
                {
                    Naziv = "Glavni podrum - Vrsac",
                    Temperatura = 12.5,
                    MaksimalniKapacitetPaleta = 150
                },
                new VinskiPodrum
                {
                    Naziv = "Skladiste Beograd",
                    Temperatura = 13.0,
                    MaksimalniKapacitetPaleta = 100
                },
                new VinskiPodrum
                {
                    Naziv = "Lokalni kelar",
                    Temperatura = 14.0,
                    MaksimalniKapacitetPaleta = 50
                },
                new VinskiPodrum
                {
                    Naziv = "Export hub Novi Sad",
                    Temperatura = 11.5,
                    MaksimalniKapacitetPaleta = 200
                }
            };

            foreach (VinskiPodrum podrum in podrumi)
            {
                _podrumRepo.Dodaj(podrum);
            }

            Console.WriteLine($"- Dodato {podrumi.Count} vinska podruma");
        }
    }
}