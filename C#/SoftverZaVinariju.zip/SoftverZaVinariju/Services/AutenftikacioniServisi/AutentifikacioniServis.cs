﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.AutenftikacioniServisi
{
    public class AutentifikacioniServis : IAutentifikacijaServis
    {
        private readonly IKorisniciRepozitorijum _korisniciRepozitorijum;
        private readonly ILoggerServis _logger;

        public AutentifikacioniServis(IKorisniciRepozitorijum korisniciRepozitorijum, ILoggerServis loggerServis)
        {
            _korisniciRepozitorijum = korisniciRepozitorijum;
            _logger = loggerServis;
        }

        public (bool, Korisnik) Prijava(string korisnickoIme, string lozinka)
        {
            if (string.IsNullOrWhiteSpace(korisnickoIme) || string.IsNullOrWhiteSpace(lozinka))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, "Pokušaj prijave sa praznim podacima");
                return (false, new Korisnik());
            }

            Korisnik korisnik = _korisniciRepozitorijum.PronadjiKorisnikaPoKorisnickomImenu(korisnickoIme);

            if (korisnik.Id != 0 && korisnik.Lozinka == lozinka)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Uspešna prijava korisnika: {korisnickoIme} ({korisnik.Uloga})");
                return (true, korisnik);
            }

            _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Neuspešna prijava na korisničko ime: {korisnickoIme}");

            return (false, new Korisnik());
        }

        public (bool, Korisnik) Registracija(Korisnik noviKorisnik)
        {
            if (noviKorisnik == null || string.IsNullOrWhiteSpace(noviKorisnik.KorisnickoIme))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Pokušaj registracije sa neispravnim podacima");
                return (false, new Korisnik());
            }

            Korisnik postojećiKorisnik = _korisniciRepozitorijum.PronadjiKorisnikaPoKorisnickomImenu(noviKorisnik.KorisnickoIme);

            if (postojećiKorisnik.Id != 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Pokušaj registracije već postojećeg korisnika: {noviKorisnik.KorisnickoIme}");
                return (false, new Korisnik());
            }

            _korisniciRepozitorijum.DodajKorisnika(noviKorisnik);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Novi korisnik registrovan: {noviKorisnik.KorisnickoIme} ({noviKorisnik.Uloga})");

            return (true, noviKorisnik);
        }
    }
}