﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.Genericki
{
    public class ProizvodnjaVinaServis : IProizvodnjaVinaServis
    {
        private readonly IVinoRepozitorijum _repo;
        private readonly IVinogradarstvoServis _vinogradarstvo;
        private readonly ILoggerServis _logger;

        public ProizvodnjaVinaServis(IVinoRepozitorijum repo, IVinogradarstvoServis vinogradarstvoServis, ILoggerServis logger)
        {
            _repo = repo;
            _vinogradarstvo = vinogradarstvoServis;
            _logger = logger;
        }


        public void EvidentirajVino(string naziv, KategorijaVina kategorija, double zapremina, string idLoze)
        {
            if (string.IsNullOrWhiteSpace(naziv) || string.IsNullOrWhiteSpace(idLoze))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Nevalidni parametri pri evidenciji vina");
                return;
            }

            if (zapremina <= 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, $"Nevalidna zapremina: {zapremina}");
                return;
            }

            // Generisanje sifre serije po sablonu: VN-2025-ID_VINA
            // Koristimo Guid za ID dela, ili timestamp
            string uniquePart = DateTime.Now.Ticks.ToString().Substring(10);
            string sifra = $"VN-{DateTime.Now.Year}-{uniquePart}";

            Vino vino = new Vino
            {
                SifraSerije = sifra,
                Naziv = naziv,
                Kategorija = kategorija,
                Zapremina = zapremina,
                IdLoze = idLoze,
                DatumFlasiranja = DateTime.Now
            };
            _repo.Dodaj(vino);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Vino evidentirano: {sifra} - {naziv} ({kategorija})");
        }

        public IEnumerable<Vino> PokreniFermentaciju(string nazivVina, KategorijaVina kategorija, int brojFlasa, ZapreminaFlase zapremina, string nazivLoze, string region)
        {
            if (brojFlasa <= 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Broj flaša mora biti veći od 0");
                return Enumerable.Empty<Vino>();
            }

            double zapreminaFlase = 1.5;
            if (zapremina == ZapreminaFlase.Mala)
                zapreminaFlase = 0.75;

            double ukupnoLitara = brojFlasa * zapreminaFlase;

            int potrebanBrojLoza = (int)Math.Ceiling(ukupnoLitara / 1.2);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Pokrenuta fermentacija: {nazivVina}, potrebno {potrebanBrojLoza} loza");

            (var loze, int kolikoFali) = _vinogradarstvo.ObratiLoze(nazivLoze, potrebanBrojLoza);
            //pogldeaj belseku u implementaciji ObratiLoze
            //tu bi trebalo posaditi loza ako fale

            if (loze == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Greška pri obiranju loza");
                return Enumerable.Empty<Vino>();
            }

            List<Loza> sveLozeProcesirane = loze.ToList();

            if (kolikoFali > 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Nedostaje {kolikoFali} loza, sadnja u toku...");

                for (int i = 0; i < kolikoFali; i++)
                {
                    var novaLoza = _vinogradarstvo.PosadiNovuLozu(nazivLoze, region);

                    if (novaLoza == null)
                    {
                        _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Neuspela sadnja loze");
                        continue;
                    }

                    novaLoza.Faza = FazaZrelosti.Obrana;
                    _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Posadjena i obrana loza {novaLoza.Id}");

                    sveLozeProcesirane.Add(novaLoza);
                }
            }

            var novoDodateLoze = new List<Loza>();
            int brojBalansiranihLoza = 0;
            foreach (var loza in sveLozeProcesirane.ToList())
            {
                if (loza.NivoSecera > 24.0)
                {
                    double visak = loza.NivoSecera - 24.0;

                    _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Loza {loza.Id} ima višak šećera: {visak} Brix, balansiranje...");

                    var novaLoza = _vinogradarstvo.PosadiNovuLozu(nazivLoze, region);

                    if (novaLoza == null)
                    {
                        _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Neuspela sadnja nove loze");
                        continue;
                    }

                    double noviNivo = novaLoza.NivoSecera - visak;

                    // Proveri da novi nivo nije ispod minimuma
                    if (noviNivo < 15.0)
                    {
                        noviNivo = 15.0;
                    }

                    if (_vinogradarstvo.PromeniNivoSecera(novaLoza.Id, noviNivo))
                    {
                        novoDodateLoze.Add(novaLoza);
                        brojBalansiranihLoza++;
                    }
                }
            }

            if (novoDodateLoze.Count > 0)
                sveLozeProcesirane.AddRange(novoDodateLoze);

            if (brojBalansiranihLoza > 0)
                _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Uspešno balansiran šećer za {brojBalansiranihLoza} loza");

            int brojProizvedenihVina = 0;

            foreach (var loza in sveLozeProcesirane.ToList())
            {
                if (brojProizvedenihVina >= brojFlasa)
                    break;

                int flasaPoLozi = (int)Math.Floor(1.2 / zapreminaFlase);
                int kolikinaZaProizvesti = Math.Min(flasaPoLozi, brojFlasa - brojProizvedenihVina);

                for (int i = 0; i < kolikinaZaProizvesti; i++)
                {
                    EvidentirajVino(nazivVina, kategorija, zapreminaFlase, loza.Id);
                    brojProizvedenihVina++;
                }
            }

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Fermentacija završena: proizvedeno {brojProizvedenihVina} flaša vina {nazivVina}");

            return _repo.PreuzmiSve()
                .Where(v => v.Naziv == nazivVina && v.Kategorija == kategorija)
                .OrderByDescending(v => v.DatumFlasiranja)
                .Take(brojFlasa);
        }

        public IEnumerable<Vino> PregledSvihVina() => _repo.PreuzmiSve();
    }
}