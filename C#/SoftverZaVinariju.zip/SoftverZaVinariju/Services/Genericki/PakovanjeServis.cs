﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.Genericki
{
    public class PakovanjeServis : IPakovanjeServis
    {
        private readonly IPaletaRepozitorijum _repo;
        private readonly IVinoRepozitorijum _vinoRepo;
        private readonly ILozaRepozitorijum _lozaRepo;
        private readonly IPodrumRepozitorijum _podrumRepo;
        private readonly IProizvodnjaVinaServis _proizvodnjaVinaServis;
        private readonly ILoggerServis _logger;
        public PakovanjeServis(IPaletaRepozitorijum repo, IVinoRepozitorijum vinoRepo, ILozaRepozitorijum lozaRepo, IPodrumRepozitorijum podrumRepo, IProizvodnjaVinaServis proizvodnjaVinaServis, ILoggerServis logger)
        {
            _repo = repo;
            _vinoRepo = vinoRepo;
            _lozaRepo = lozaRepo;
            _podrumRepo = podrumRepo;
            _proizvodnjaVinaServis = proizvodnjaVinaServis;
            _logger = logger;
        }

        public IEnumerable<Paleta> PregledPaleta() => _repo.PreuzmiSve();

        public (bool, string) KreirajPaletu(string adresa, string idPodruma, List<string> vinaIds)
        {
            if (string.IsNullOrWhiteSpace(adresa))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Adresa odredišta je prazna");
                return (false, string.Empty);
            }

            if (string.IsNullOrWhiteSpace(idPodruma))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "ID podruma je prazan");
                return (false, string.Empty);
            }

            if (vinaIds == null || vinaIds.Count == 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Paleta mora sadržati bar jedno vino");
                return (false, string.Empty);
            }

            VinskiPodrum? podrum = _podrumRepo.PreuzmiSve().FirstOrDefault(p => p.Id == idPodruma);

            if (podrum == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, $"Podrum sa ID {idPodruma} ne postoji");
                return (false, string.Empty);
            }

            IEnumerable<Vino> svaVina = _proizvodnjaVinaServis.PregledSvihVina();
            foreach (string idVina in vinaIds)
            {
                if (!svaVina.Any(v => v.SifraSerije == idVina))
                {
                    _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, $"Vino {idVina} ne postoji");
                    return (false, string.Empty);
                }
            }

            IEnumerable<Paleta> svePalete = _repo.PreuzmiSve();
            foreach (Paleta postojecaPaleta in svePalete)
            {
                foreach (string idVina in vinaIds)
                {
                    if (postojecaPaleta.SpisakVinaIds.Contains(idVina))
                    {
                        _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Vino {idVina} je već spakovano u paletu {postojecaPaleta.Sifra}");
                        return (false, string.Empty);
                    }
                }
            }

            if (vinaIds.Count == 0)
            {
                return (false, string.Empty);
            }

            Paleta paleta = new Paleta
            {
                AdresaOdredista = adresa,
                IdVinskogPodruma = idPodruma,
                SpisakVinaIds = vinaIds,
                Status = StatusPalete.Upakovana
            };

            _repo.Dodaj(paleta);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Paleta {paleta.Sifra} kreirana sa {vinaIds.Count} vina, odrediste: {adresa}");

            return (true, paleta.Sifra);
        }

        public (bool, string) OtpremiPaletu(string sifraPalete, string idPodruma)
        {
            if (string.IsNullOrWhiteSpace(sifraPalete))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Šifra palete je prazna");
                return (false, "GREŠKA: Šifra palete je prazna");
            }

            Paleta? paleta = _repo.PreuzmiSve().FirstOrDefault(p => p.Sifra == sifraPalete);

            if (paleta == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, $"Paleta {sifraPalete} ne postoji");
                return (false, "GREŠKA: Paleta sa tom šifrom ne postoji.");
            }
            string sifraKreiranePalete;
            if (paleta.Status != StatusPalete.Upakovana)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Paleta {sifraPalete} nije upakovana, kreirajne nove zapoceto!");
                string adr = paleta.AdresaOdredista;
                string idPodrumaStara = paleta.IdVinskogPodruma;
                List<string> vinaIds = paleta.SpisakVinaIds;
                (_, sifraKreiranePalete) = KreirajPaletu(adr, idPodruma, vinaIds);
                paleta = _repo.PreuzmiSve().FirstOrDefault(p => p.Sifra == sifraKreiranePalete);

            }

            VinskiPodrum? podrum = _podrumRepo.PreuzmiSve().FirstOrDefault(p => p.Id == idPodruma);

            if (podrum == null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, $"Podrum {idPodruma} ne postoji");
                return (false, "GREŠKA: Vinski podrum sa tim ID-om ne postoji.");
            }

            int brojPaletaUPodrumu = _repo.PreuzmiSve().Count(p => p.IdVinskogPodruma == idPodruma && p.Status == StatusPalete.Otpremljena);

            if (brojPaletaUPodrumu >= podrum.MaksimalniKapacitetPaleta)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Podrum '{podrum.Naziv}' je popunjen ({brojPaletaUPodrumu}/{podrum.MaksimalniKapacitetPaleta})");
                return (false, $"GREŠKA: Podrum '{podrum.Naziv}' je popunjen. Maksimalni kapacitet: {podrum.MaksimalniKapacitetPaleta}");
            }

            paleta.Status = StatusPalete.Otpremljena;
            paleta.IdVinskogPodruma = idPodruma;

            _repo.Azuriraj(paleta);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Paleta {sifraPalete} otpremljena u podrum '{podrum.Naziv}' ({brojPaletaUPodrumu + 1}/{podrum.MaksimalniKapacitetPaleta})");

            return (true, $"Paleta {sifraPalete} uspešno otpremljena u podrum '{podrum.Naziv}'.");
        }

        public IEnumerable<Vino> Raspakuj(Paleta paleta)
        {
            List<Vino> vina = new List<Vino>();

            foreach (string vinoId in paleta.SpisakVinaIds)
            {
                var vino = _vinoRepo.PreuzmiSaId(vinoId);
                if (vino != null)
                {
                    vina.Add(vino);
                }
            }

            return vina;
        }

        public void DelegirajFermentacijuBuraz(string vinoID, int brojFlasa)  //krajiski duo resio
        {
            ZapreminaFlase zapremina = ZapreminaFlase.Velika;
            Vino vinoKojeFali = _vinoRepo.PreuzmiSaId(vinoID);
            string nazivVina = vinoKojeFali.Naziv;
            KategorijaVina kategorija = vinoKojeFali.Kategorija;
            Loza lozaVinaKojeFali = _lozaRepo.PreuzmiSaId(vinoKojeFali.IdLoze);
            string nazivLoze = lozaVinaKojeFali.Naziv;
            string region = lozaVinaKojeFali.Region;
            _proizvodnjaVinaServis.PokreniFermentaciju(nazivVina, kategorija, brojFlasa, zapremina, nazivLoze, region);
        }
    }
}