﻿using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.Genericki
{
    public class VinogradarstvoServis : IVinogradarstvoServis
    {
        private readonly ILozaRepozitorijum _repo;
        private readonly ILoggerServis _logger;

        public VinogradarstvoServis(ILozaRepozitorijum repo, ILoggerServis logger)
        {
            _repo = repo;
            _logger = logger;
        }

        public void EvidentirajLozu(string naziv, double secer, int godina, string region, FazaZrelosti faza)
        {
            Loza loza = new Loza
            {
                Naziv = naziv,
                NivoSecera = secer,
                GodinaSadnje = godina,
                Region = region,
                Faza = faza
            };
            _repo.Dodaj(loza);
        }

        public Loza PosadiNovuLozu(string naziv, string region)
        {
            if (string.IsNullOrWhiteSpace(naziv) || string.IsNullOrWhiteSpace(region))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Nevalidni parametri za sadnju loze");
                return new Loza();
            }

            var random = new Random();
            double secer = 15.0 + random.NextDouble() * 13.0;

            var loza = new Loza
            {
                Naziv = naziv,
                NivoSecera = Math.Round(secer, 2),
                GodinaSadnje = DateTime.Now.Year,
                Region = region,
                Faza = FazaZrelosti.Posadjena
            };

            _repo.Dodaj(loza);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Loza posadjena: {naziv} u regionu {region}, nivo secera: {loza.NivoSecera} Brix");

            return loza;
        }

        public bool PromeniNivoSecera(string lozaId, double noviNivo)
        {
            if (string.IsNullOrWhiteSpace(lozaId))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Prazan ID loze");
                return false;
            }

            Loza loza = _repo.PreuzmiSaId(lozaId);

            if (loza is null)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, $"Loza sa ID {lozaId} ne postoji");
                return false;
            }

            if (noviNivo < 15.0 || noviNivo > 28.0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Nivo šećera {noviNivo} je van opsega (15.0-28.0 Brix)");
                return false;
            }

            //  double faktor = 1 + procenat / 100.0;
            //  double noviNivo = loza.NivoSecera * faktor;

            if (noviNivo < 0)
                return false;

            double stariNivo = loza.NivoSecera;

            loza.NivoSecera = Math.Round(noviNivo, 2);

            _repo.Azuriraj(lozaId);

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Promena šećera loze {lozaId}: {stariNivo} -> {noviNivo} Brix");

            return true;
        }

        public IEnumerable<Loza> PregledSvihLoza() => _repo.PreuzmiSve();

        public (IEnumerable<Loza>, int) ObratiLoze(string nazivSorte, int brojLoza)
        {
            if (string.IsNullOrWhiteSpace(nazivSorte))
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Naziv sorte je prazan");
                return (Enumerable.Empty<Loza>(), brojLoza);
            }

            if (brojLoza <= 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.ERROR, "Broj loza mora biti veći od 0");
                return (Enumerable.Empty<Loza>(), 0);
            }

            var lozeZaBerbu = _repo.PreuzmiSve()
                .Where(l => l.Naziv == nazivSorte &&
                            l.Faza == FazaZrelosti.SpremnaZaBerbu)
                .Take(brojLoza)
                .ToList();

            if (lozeZaBerbu.Count < brojLoza)
                return (lozeZaBerbu, brojLoza - lozeZaBerbu.Count);
            //ovde bi onda trebalo da vrati koliko loza fali da se posadi tj broj= brojLoza - lozeZaBerbu.Count
            // Vlada: vratiti obrane + broj koliko fali

            foreach (var loza in lozeZaBerbu)
            {
                loza.Faza = FazaZrelosti.Obrana;
                _repo.Azuriraj(loza.Id);
            }

            int kolikoFali = brojLoza - lozeZaBerbu.Count;

            if (kolikoFali > 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, $"Nedovoljno loza sorte {nazivSorte}. Obrano: {lozeZaBerbu.Count}, fali: {kolikoFali}");
            }
            else
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Uspešno obrano {lozeZaBerbu.Count} loza sorte {nazivSorte}"
                );
            }

            return (lozeZaBerbu, 0);
        }
    }
}