﻿using Domain.Enumeracije;
using Domain.Konstante;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.SkladistenjeServisi
{
    public class PodrumSkladistenjeServis : ISkladistenjeServis
    {
        const int MAX_PALETA = KolicinaKonstante.VINSKI_PODRUM_PALETA;
        const int TRAJANJE = VremeKonstante.VINSKI_PODRUM_TRAJANJE;

        private readonly IPodrumRepozitorijum _podrumRepo;
        private readonly IPaletaRepozitorijum _paletaRepo;
        private readonly ILoggerServis _loggerServis;
        public PodrumSkladistenjeServis(IPodrumRepozitorijum repo, IPaletaRepozitorijum paletaRepo, ILoggerServis loggerServis)
        {
            _podrumRepo = repo;
            _paletaRepo = paletaRepo;
            _loggerServis = loggerServis;
        }

        public void EvidentirajPodrum(string naziv, double temperatura, int kapacitet)
        {
            VinskiPodrum podrum = new VinskiPodrum
            {
                Naziv = naziv,
                Temperatura = temperatura,
                MaksimalniKapacitetPaleta = kapacitet
            };
            _podrumRepo.Dodaj(podrum);
            _loggerServis.EvidentirajDogadjaj(TipEvidencije.INFO, $"Podrum evidentiran: {naziv} sa kapacitetom {kapacitet} paleta.");
        }

        public IEnumerable<Paleta> IsporuciPalete(int brojPaleta)
        {
            List<Paleta> palete = _paletaRepo.PreuzmiSve()
                .Where(p => p.Status == StatusPalete.Otpremljena) // Ne treba upakovana, već otpremljena u podrum
                .Take(brojPaleta)
                .ToList();

            int originalanBrojPaleta = brojPaleta;

            while (brojPaleta > 0)
            {
                if (palete.Count == 0)
                    break;

                int brojac = 0;

                foreach (var paleta in palete)
                {
                    if (brojac < MAX_PALETA && brojPaleta > 0)
                    {
                        Task.Delay(TRAJANJE).Wait();
                        paleta.Status = StatusPalete.Otpremljena;
                        _paletaRepo.Azuriraj(paleta);
                        brojPaleta--;
                        brojac++;
                    }
                }
                break;
            }

            _loggerServis.EvidentirajDogadjaj(TipEvidencije.INFO, $"{originalanBrojPaleta} paleta isporučeno.");
            return palete;
        }

        public IEnumerable<VinskiPodrum> PregledPodruma() => _podrumRepo.PreuzmiSve();
    }
}