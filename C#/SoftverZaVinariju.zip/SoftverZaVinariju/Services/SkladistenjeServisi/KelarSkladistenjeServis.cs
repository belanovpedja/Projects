﻿using Domain.Enumeracije;
using Domain.Konstante;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;

namespace Services.SkladistenjeServisi
{
    public class KelarSkladistenjeServis : ISkladistenjeServis
    {
        const int MAX_PALETA = KolicinaKonstante.LOKALNI_KELAR_PALETA;
        const int TRAJANJE = VremeKonstante.LOKALNI_KELAR_TRAJANJE;

        private readonly IPaletaRepozitorijum _paletaRepo;
        private readonly ILoggerServis _logger;

        public KelarSkladistenjeServis(IPaletaRepozitorijum paletaRepo, ILoggerServis logger)
        {
            _paletaRepo = paletaRepo;
            _logger = logger;
        }

        public void EvidentirajPodrum(string naziv, double temperatura, int kapacitet)
        {
        }

        public IEnumerable<Paleta> IsporuciPalete(int brojPaleta)
        {
            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Zahtev za isporuku {brojPaleta} paleta primljen.");

            List<Paleta> palete = _paletaRepo.PreuzmiSve()
                .Where(p => p.Status == StatusPalete.Upakovana)
                .Take(brojPaleta)
                .ToList();

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Pronađeno {palete.Count} upakovanih paleta pogodnih za isporuku.");

            if (palete.Count == 0)
            {
                _logger.EvidentirajDogadjaj(TipEvidencije.WARNING, "Nema dostupnih upakovanih paleta za isporuku.");
                return palete;
            }

            int preostaloZaIsporuku = brojPaleta;
            int ukupnoIsporuceno = 0;

            while (preostaloZaIsporuku > 0)
            {
                int brojac = 0;

                foreach (var paleta in palete)
                {
                    if (brojac < MAX_PALETA && preostaloZaIsporuku > 0)
                    {
                        Task.Delay(TRAJANJE).Wait();
                        paleta.Status = StatusPalete.Otpremljena;
                        _paletaRepo.Azuriraj(paleta);
                        preostaloZaIsporuku--;
                        brojac++;
                        ukupnoIsporuceno++;

                        _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Paleta ({paleta.Sifra}) promenjena u Otpremljena i ažurirana u repozitorijumu.");
                    }
                }
                break;
            }

            _logger.EvidentirajDogadjaj(TipEvidencije.INFO, $"Isporuka završena. Traženo: {brojPaleta}, Isporučeno: {ukupnoIsporuceno}.");

            return palete;
        }

        public IEnumerable<VinskiPodrum> PregledPodruma()
        {
            return new List<VinskiPodrum>();
        }
    }
}
