﻿using Domain.BazaPodataka;
using System.Xml.Serialization;

namespace Database.BazaPodataka
{
    public class XMLBazaPodataka : IBazaPodataka
    {
        private readonly string _putanja = "VinarijaDB.xml";
        public TabeleBazaPodataka Tabele { get; private set; } = new TabeleBazaPodataka();

        public XMLBazaPodataka()
        {
            UcitajSve();
        }

        public bool SacuvajSve()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(TabeleBazaPodataka));
            using (StreamWriter writer = new StreamWriter(_putanja))
            {
                serializer.Serialize(writer, Tabele);
            }

            return true;
        }

        public void UcitajSve()
        {
            if (!File.Exists(_putanja))
            {
                Tabele = new TabeleBazaPodataka();
                return;
            }

            XmlSerializer serializer = new XmlSerializer(typeof(TabeleBazaPodataka));
            using (StreamReader reader = new StreamReader(_putanja))
            {
                var deserialized = serializer.Deserialize(reader) as TabeleBazaPodataka;
                Tabele = deserialized ?? new TabeleBazaPodataka();
            }
        }
    }
}
