﻿using Domain.BazaPodataka;
using Domain.Modeli;
using Domain.Repozitorijumi;

namespace Database.Repozitorijumi
{
    public class VinoRepozitorijum : IVinoRepozitorijum
    {
        private readonly IBazaPodataka _baza;
        public VinoRepozitorijum(IBazaPodataka baza) { _baza = baza; }

        public void Dodaj(Vino vino)
        {
            _baza.Tabele.Vina.Add(vino);
            _baza.SacuvajSve();
        }

        public Vino PreuzmiSaId(string id)
        {
            return _baza.Tabele.Vina.FirstOrDefault(v => v.SifraSerije == id)!;
        }

        public IEnumerable<Vino> PreuzmiSve() => _baza.Tabele.Vina;
    }
}