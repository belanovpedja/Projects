﻿using Domain.BazaPodataka;
using Domain.Modeli;
using Domain.Repozitorijumi;

namespace Database.Repozitorijumi
{
    public class LozaRepozitorijum : ILozaRepozitorijum
    {
        private readonly IBazaPodataka _baza;
        public LozaRepozitorijum(IBazaPodataka baza) { _baza = baza; }
        public void Dodaj(Loza loza)
        {
            if (_baza.Tabele.Loze.Any(l => l.Id == loza.Id))
                return;

            _baza.Tabele.Loze.Add(loza);
            _baza.SacuvajSve();
        }
        public IEnumerable<Loza> PreuzmiSve() => _baza.Tabele.Loze;

        public Loza PreuzmiSaId(string id)
        {
            return _baza.Tabele.Loze.FirstOrDefault(l => l.Id == id)!;
        }

        public void Azuriraj(string lozaId)
        {
            _baza.SacuvajSve();
        }
    }
}