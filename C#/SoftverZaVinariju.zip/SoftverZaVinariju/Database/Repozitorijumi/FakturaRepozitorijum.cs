﻿using Domain.BazaPodataka;
using Domain.Modeli;
using Domain.Repozitorijumi;

namespace Database.Repozitorijumi
{
    public class FakturaRepozitorijum : IFakturaRepozitorijum
    {
        private readonly IBazaPodataka _bazaPodataka;

        public FakturaRepozitorijum(IBazaPodataka bazaPodataka)
        {
            _bazaPodataka = bazaPodataka;
        }

        public bool Sacuvaj(Faktura faktura)
        {
            _bazaPodataka.Tabele.Fakture.Add(faktura);
            return _bazaPodataka.SacuvajSve();
        }

        public IEnumerable<Faktura> PreuzmiSve()
        {
            return _bazaPodataka.Tabele.Fakture;
        }

        public Faktura DodajVino(Faktura fakt, Vino vino, int kolicina, double cena)
        {
            double ukupno = kolicina * cena;
            StavkaFakture stavka = new StavkaFakture
            {
                NazivVina = vino.Naziv,
                Kolicina = kolicina,
                CenaPoKomadu = cena
            };
            fakt.Stavke.Add(stavka);
            fakt.UkupanIznos += ukupno;

            return fakt;
        }
    }
}