﻿using Domain.BazaPodataka;
using Domain.Modeli;
using Domain.Repozitorijumi;

namespace Database.Repozitorijumi
{
    public class PaletaRepozitorijum : IPaletaRepozitorijum
    {
        private readonly IBazaPodataka _baza;

        public PaletaRepozitorijum(IBazaPodataka baza)
        {
            _baza = baza;
        }

        public void Dodaj(Paleta paleta)
        {
            _baza.Tabele.Palete.Add(paleta);
            _baza.SacuvajSve();
        }

        public IEnumerable<Paleta> PreuzmiSve() => _baza.Tabele.Palete;

        public void Azuriraj(Paleta paleta)
        {
            _baza.SacuvajSve();
        }
    }
}