﻿using Domain.BazaPodataka;
using Domain.Modeli;
using Domain.Repozitorijumi;

namespace Database.Repozitorijumi
{
    public class PodrumRepozitorijum : IPodrumRepozitorijum
    {
        private readonly IBazaPodataka _baza;
        public PodrumRepozitorijum(IBazaPodataka baza) { _baza = baza; }

        public void Dodaj(VinskiPodrum podrum)
        {
            _baza.Tabele.Podrumi.Add(podrum);
            _baza.SacuvajSve();
        }
        public IEnumerable<VinskiPodrum> PreuzmiSve() => _baza.Tabele.Podrumi;
    }
}