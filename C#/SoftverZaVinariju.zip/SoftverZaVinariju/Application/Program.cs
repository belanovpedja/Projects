﻿using Database.BazaPodataka;
using Database.Repozitorijumi;
using Domain.BazaPodataka;
using Domain.Enumeracije;
using Domain.Modeli;
using Domain.Repozitorijumi;
using Domain.Servisi;
using Presentation.Authentifikacija;
using Presentation.Enolog;
using Presentation.Kelar;
using Services.AutenftikacioniServisi;
using Services.Genericki;
using Services.Inicijalizacija;
using Services.LoggerServis;
using Services.ProdajaServisi;
using Services.SkladistenjeServisi;

// ВРШАЦ ТИМ 07 ВИНАРИЈА ДРШАКОВИЋ

namespace Loger_Bloger
{
    public class Program
    {
        public static void Main()
        {
            // Baza podataka
            IBazaPodataka bazaPodataka = new XMLBazaPodataka();

            // Repozitorijumi
            IKorisniciRepozitorijum korisniciRepozitorijum = new KorisniciRepozitorijum(bazaPodataka);
            ILozaRepozitorijum lozaRepozitorijum = new LozaRepozitorijum(bazaPodataka);
            IVinoRepozitorijum vinoRepozitorijum = new VinoRepozitorijum(bazaPodataka);
            IPaletaRepozitorijum paletaRepozitorijum = new PaletaRepozitorijum(bazaPodataka);
            IPodrumRepozitorijum podrumRepozitorijum = new PodrumRepozitorijum(bazaPodataka);
            IFakturaRepozitorijum faktureRepozitorijum = new FakturaRepozitorijum(bazaPodataka);

            // Ako nema nijednog korisnika u sistemu, dodati dva nova
            if (korisniciRepozitorijum.SviKorisnici().Count() == 0)
            {
                // Inicijalizacija testnih podataka
                InicijalizacijaPodataka inicijalizacija = new InicijalizacijaPodataka(korisniciRepozitorijum, lozaRepozitorijum, vinoRepozitorijum, podrumRepozitorijum);
                inicijalizacija.InicijalizujPodatke();
            }

            Console.WriteLine("TESTNI NALOZI:");
            Console.WriteLine("  Glavni Enolog: enolog / enolog123");
            Console.WriteLine("  Kelar Majstor: kelar / kelar123");

            // Servisi
            ILoggerServis loggerServis = new LoggerServis();
            IAutentifikacijaServis autentifikacijaServis = new AutentifikacioniServis(korisniciRepozitorijum, loggerServis);
            IVinogradarstvoServis vinogradarstvoServis = new VinogradarstvoServis(lozaRepozitorijum, loggerServis);
            IProizvodnjaVinaServis proizvodnjaVinaServis = new ProizvodnjaVinaServis(vinoRepozitorijum, vinogradarstvoServis, loggerServis);
            IPakovanjeServis pakovanjeServis = new PakovanjeServis(paletaRepozitorijum, vinoRepozitorijum, lozaRepozitorijum, podrumRepozitorijum, proizvodnjaVinaServis, loggerServis);

            // Prezentacioni sloj
            PrijavaMeni pm = new PrijavaMeni(autentifikacijaServis);
            Korisnik korisnik = pm.PrikaziOpcije();

            Console.Clear();
            Console.WriteLine($"Uspešno ste prijavljeni kao: {korisnik.Ime} {korisnik.Prezime} ({korisnik.Uloga})");

            if (korisnik.Uloga == TipKorisnika.GlavniEnolog)
            {
                ISkladistenjeServis skladistenjeServis = new PodrumSkladistenjeServis(podrumRepozitorijum, paletaRepozitorijum, loggerServis);
                IProdajaServis prodajaServis = new ProdajaServis(faktureRepozitorijum, vinoRepozitorijum, skladistenjeServis, pakovanjeServis, loggerServis, korisnik.Uloga);
                EnologMeni em = new EnologMeni(prodajaServis, proizvodnjaVinaServis, skladistenjeServis, vinogradarstvoServis, pakovanjeServis);
                em.Prikazi();
            }
            else if (korisnik.Uloga == TipKorisnika.Kelar)
            {
                ISkladistenjeServis skladistenjeServis = new KelarSkladistenjeServis(paletaRepozitorijum, loggerServis);
                IProdajaServis prodajaServis = new ProdajaServis(faktureRepozitorijum, vinoRepozitorijum, skladistenjeServis, pakovanjeServis, loggerServis, korisnik.Uloga);
                KelarMeni km = new KelarMeni(prodajaServis, vinogradarstvoServis, pakovanjeServis, proizvodnjaVinaServis, skladistenjeServis);
                km.Prikazi();
            }
        }
    }
}